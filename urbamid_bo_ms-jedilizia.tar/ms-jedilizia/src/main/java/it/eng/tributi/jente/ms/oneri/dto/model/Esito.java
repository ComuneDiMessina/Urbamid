package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;

public class Esito implements Serializable{
    private static final long serialVersionUID = 1L;

    protected boolean ok;
    protected String messaggio;

    /**
     * Gets the value of the ok property.
     * 
     */
    public boolean isOk() {
        return ok;
    }

    /**
     * Sets the value of the ok property.
     * 
     */
    public void setOk(boolean value) {
        this.ok = value;
    }

    /**
     * Gets the value of the messaggio property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessaggio() {
        return messaggio;
    }

    /**
     * Sets the value of the messaggio property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessaggio(String value) {
        this.messaggio = value;
    }

    public static Esito getInstance() {
        Esito retval = new Esito();
        return retval;
    }

    public static Esito populateExample(Esito esito) {
        Esito retval = esito;
        retval.setOk(true);
        retval.setMessaggio("");
        return retval;
    }
    
    public static Esito creaMessaggioOK(Esito esito) {
        Esito retval = esito;
        retval.setOk(true);
        retval.setMessaggio("");
        return retval;
    }

    public static Esito creaMessaggioKO(Esito esito, String messaggio) {
        Esito retval = esito;
        retval.setOk(false);
        retval.setMessaggio(messaggio);
        return retval;
    }
    
}
