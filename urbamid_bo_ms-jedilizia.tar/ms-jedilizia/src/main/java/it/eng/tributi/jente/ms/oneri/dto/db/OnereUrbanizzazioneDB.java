package it.eng.tributi.jente.ms.oneri.dto.db;

import it.eng.tributi.jente.ms.oneri.dto.db.DBOrmHistory;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=true)
@SuperBuilder
public class OnereUrbanizzazioneDB extends DBOrmHistory {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriUrbaniz;
	protected String unitaMisura;
	protected BigDecimal quantita;
	protected BigDecimal tributo1;
	protected BigDecimal detrazione1;
	protected BigDecimal tributo2;
	protected BigDecimal detrazione2;
	
}
