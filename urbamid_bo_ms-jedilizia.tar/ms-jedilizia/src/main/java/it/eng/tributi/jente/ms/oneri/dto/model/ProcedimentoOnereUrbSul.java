package it.eng.tributi.jente.ms.oneri.dto.model;

import it.eng.tributi.jente.ms.oneri.dto.model.OnereUrbanizzazioneCalcolo;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProcedimentoOnereUrbSul implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriUrbSul;
	protected Long idProcedimento;
	protected Long idOneriDestinazioneUso;
	protected String parametro2;
	protected BigDecimal volumeVuotoPerPieno;
	protected String parametro1;
	
	public static List<OnereUrbanizzazioneCalcolo> linkOnereUrbCalcFromModel(List<ProcedimentoOnereUrbSul> items){
		 ArrayList<OnereUrbanizzazioneCalcolo> links = new ArrayList<>();
	        for (ProcedimentoOnereUrbSul item : items) {
	        	OnereUrbanizzazioneCalcolo link = OnereUrbanizzazioneCalcolo.builder()
	        			.idOneriDestinazioneUso(item.getIdOneriDestinazioneUso())
	        			.parametro2(item.getParametro2())
	        			.parametro1(item.getParametro1())
                                        .volumeVuotoPerPieno(item.getVolumeVuotoPerPieno())
	        			.build();
	            links.add(link);
	        }
	        return links;
	}
}
