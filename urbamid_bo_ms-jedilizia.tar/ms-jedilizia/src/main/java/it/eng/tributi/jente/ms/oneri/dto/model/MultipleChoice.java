package it.eng.tributi.jente.ms.oneri.dto.model;

import it.arezzo.infor.jente.jadmin.service.util.Util;
import it.eng.tributi.jente.ms.oneri.util.Utils;
import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class MultipleChoice extends SingleChoice {


	private static final long serialVersionUID = 1L;
	protected String label1;
	protected String label2;
       
     public static MultipleChoice getMultipleChoice(OnereIncremento onereIncremento, String label1, String label2) {     
        MultipleChoice multipleChoice = (MultipleChoice) Utils.converti(getSingleChoice(onereIncremento),MultipleChoice.class);
        multipleChoice.setLabel1(label1);
        multipleChoice.setLabel2(label2);
        return multipleChoice;
    }    
     
    public static MultipleChoice getMultipleChoice(OnereCoefficiente onereCoefficiente, String label1, String label2) {
        MultipleChoice multipleChoice = (MultipleChoice) Utils.converti(getSingleChoice(onereCoefficiente),MultipleChoice.class);
        multipleChoice.setCodice(onereCoefficiente.getCodCoefficiente());
        multipleChoice.setDescrizione(onereCoefficiente.getDescrizione());      
        multipleChoice.setLabel1(label1);
        multipleChoice.setLabel2(label2);
        return multipleChoice;
    }
}
