package it.eng.tributi.jente.ms.oneri.dto.api;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OnereCostruzioneApi implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriCostruzione;
	protected BigDecimal costo;
	protected BigDecimal percentuale;
	protected BigDecimal detrazione;
	protected Date rowTsMod;
		
}
