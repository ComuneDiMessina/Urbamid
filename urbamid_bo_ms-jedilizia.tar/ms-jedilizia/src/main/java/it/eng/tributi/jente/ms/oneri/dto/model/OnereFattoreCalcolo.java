package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class OnereFattoreCalcolo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriFattoriCalcolo;
	protected Long idOneriDestinazioneUso;
	protected String parametro1;
	protected String parametro2;
	protected BigDecimal tariffaPrimaria;
	protected BigDecimal tariffaSecondaria;

}
