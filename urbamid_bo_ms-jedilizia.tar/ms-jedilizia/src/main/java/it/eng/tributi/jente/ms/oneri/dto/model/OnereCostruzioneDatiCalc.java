package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OnereCostruzioneDatiCalc implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected String destUso;
	protected BigDecimal supTot;
	protected BigDecimal costoCostr;
	protected BigDecimal percMagg;
	protected BigDecimal percCostoCostr;
	
}
