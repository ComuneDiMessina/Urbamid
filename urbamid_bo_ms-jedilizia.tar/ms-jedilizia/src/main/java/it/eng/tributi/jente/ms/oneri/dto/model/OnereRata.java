package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import it.eng.tributi.jente.ms.oneri.dto.db.OnereRataDB;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OnereRata implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriRata;
	protected Long tipoOneriRata;
	protected Long rata;
	protected Date dataScadenza;
	protected BigDecimal importo;
	protected BigDecimal impInteresseRata;
	protected BigDecimal pagato;
	protected BigDecimal impSanzione;
	protected Date dataPagamento;
	protected Date dataPagSanzione;
	
	public int hashKey() {
		final int prime = 31;
		int result = 0;
		result = prime * result + ((idOneriRata == null) ? 0 : idOneriRata.hashCode());
		return result;
	}
	
	public OnereRataDB getDBDTO() {
		return OnereRataDB.builder()
		.idOneriRata(idOneriRata)
		.tipoOneriRata(tipoOneriRata)
		.rata(idOneriRata)
		.dataScadenza(dataScadenza)
		.importo(importo)
		.pagato(pagato)
		.impSanzione(impSanzione)
		.dataPagamento(dataPagamento)
		.dataPagSanzione(dataPagSanzione)
		.build();
	}
	
}
