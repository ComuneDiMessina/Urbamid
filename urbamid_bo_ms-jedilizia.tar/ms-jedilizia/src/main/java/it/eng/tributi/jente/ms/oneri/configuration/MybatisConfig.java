/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.eng.tributi.jente.ms.oneri.configuration;

import javax.naming.NamingException;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.apache.commons.dbcp.BasicDataSource;
import org.eclipse.jetty.plus.jndi.Resource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
/**
 *
 * @author FABRIZIO
 */
@Configuration
@MapperScan("it.eng.tributi.jente.ms.oneri.dao.mappers")
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class, HibernateJpaAutoConfiguration.class})

public class MybatisConfig {
    
    @Autowired
    private Environment env;   
    @Value("${application.enti.lavoro}")
    private String[] entiLavoro;  

    public BasicDataSource dataSource() {
        BasicDataSource datasource = new BasicDataSource();
        datasource.setUrl(env.getProperty("application."+entiLavoro[0]+".db.url"));
        datasource.setDriverClassName(env.getProperty("application."+entiLavoro[0]+".db.driver"));
        datasource.setUsername(env.getProperty("application."+entiLavoro[0]+".db.user"));
        datasource.setPassword(env.getProperty("application."+entiLavoro[0]+".db.password"));
        datasource.setInitialSize(Integer.parseInt(env.getProperty("application."+entiLavoro[0]+".db.initialSize", "5")));
        datasource.setMaxActive(Integer.parseInt(env.getProperty("application."+entiLavoro[0]+".db.maxActive", "20")));
        datasource.setMinIdle(Integer.parseInt(env.getProperty("application."+entiLavoro[0]+".db.minIdle", "10")));
        datasource.setMaxWait(Integer.parseInt(env.getProperty("application."+entiLavoro[0]+".db.maxWait", "30000")));
        datasource.setLogAbandoned(Boolean.parseBoolean(env.getProperty("application."+entiLavoro[0]+".db.logAbandoned", "true")));
        datasource.setRemoveAbandoned(Boolean.parseBoolean(env.getProperty("application."+entiLavoro[0]+".db.removeAbandoned", "true")));
        datasource.setRemoveAbandonedTimeout(Integer.parseInt(env.getProperty("application."+entiLavoro[0]+".db.removeAbandonedTimeout", "300")));
        try {
            Resource resource = new Resource(env.getProperty("application."+entiLavoro[0]+".db.jndi-name"), datasource);
        } catch (NamingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
                    }      
        return datasource;
    }
 
    @Bean
    public SqlSessionFactory sqlSessionFactory() throws Exception {
        SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
        factoryBean.setDataSource(dataSource());
        return factoryBean.getObject();
    }
}
