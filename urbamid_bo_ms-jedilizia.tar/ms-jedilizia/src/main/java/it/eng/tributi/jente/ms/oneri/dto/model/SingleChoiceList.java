package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class SingleChoiceList implements Serializable {

	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;

	protected List<SingleChoice> singleChoiceList;
        protected String label;
        
   
    
}
