package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.util.Date;

import it.eng.tributi.jente.ms.oneri.dto.db.ResponsabileDB;
import it.eng.tributi.jente.ms.oneri.util.Utils;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Responsabile implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static final String MANSIONE_ISTRUTTORE = "I";
	public static final String MANSIONE_SUPPORTO_SEGRETERIA = "SS";
	public static final String MANSIONE_SUPPORTO_AMMINISTRATIVO = "SA";
	public static final String MANSIONE_DIRIGENTE = "D";
	public static final String MANSIONE_RESPONSABILE = "R";
	
	protected Long idResponsabile;
	protected Utente utente;
	protected Date dataIni;
	protected Date dataFine;
	protected Sezione sezione;
	protected Boolean flagPrincipale;
	protected String mansione;
	
	public boolean isDisabled() {
		return !Utils.isDateActive(dataFine);
	}
	
	public ResponsabileDB getDBDTO() {
		return ResponsabileDB.builder()
				.idResponsabile(idResponsabile)
				.idUtente(utente.getIdUtente())
				.dataIni(dataIni)
				.dataFine(dataFine)
				.mansione(mansione)
				.idSezione(sezione.getIdSezione())
				.flagPrincipale(flagPrincipale)
				.build();
	}
	
	
	public String getUtenteSezione() {
		return getSezione().getNome() +" - "+ (utente != null?utente.getNominativo():"") ;
	}
	
}
