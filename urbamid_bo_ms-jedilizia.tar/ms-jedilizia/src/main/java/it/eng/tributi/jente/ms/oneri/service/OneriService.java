package it.eng.tributi.jente.ms.oneri.service;

import it.eng.tributi.jente.ms.oneri.dto.model.Document;
import java.math.BigDecimal;
import java.util.List;

import it.eng.tributi.jente.ms.oneri.dto.model.OnereCoefficiente;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereFattoreCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereIncremento;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereUrbanizzazioneCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.OneriCostruzioneCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereResponse;
import java.util.HashMap;

public interface OneriService {
	
//	OneriModel calcolaOneri(OneriModel oneriModel);
        OnereResponse calcOneriUrbanizzazione(List<OnereUrbanizzazioneCalcolo> oneriUrb,HashMap<String, String> oneriMap, String codEnte,String tipoPagamento, boolean daPagareSubito);
//	OnereResponse calcOneriParcheggio(List<OneriParcheggiCalcolo> oneriParch, String codEnte);
	OnereResponse calcOneriCostruzione(OneriCostruzioneCalcolo oneriCostr, HashMap<String, String> oneriMap, String codEnte,String tipoPagamento, boolean daPagareSubito);
//	OnereResponse verifOneriUrbanizzazione(OneriCostruzioneCalcolo oneriCostr, BigDecimal coeffAbb, BigDecimal sulAbitInf2000, BigDecimal supTotCommTur, String codEnte);
//	OnereResponse verifOneriCostruzione(List<OnereUrbanizzazioneCalcolo> oneriUrb, String codEnte);
////	OnereResponse verifOneriParcheggio(List<OneriParcheggiCalcolo> oneriParch, String codEnte);
//	List<ProcedimentoOnereCostrSul> selectProcOnereCostrSulByIdProc(Long idProcedimento);
//	List<ProcedimentoOnereUrbSul> selectProcOnereUrbSulByIdProc(Long idProcedimento);
//	List<ProcedimentoOnereParchSul> selectProcOnereParchSulByIdProc(Long idProcedimento);
//	List<OnereCostruzione> selectOneriCostruzione (Long idProcedimento);
        Document getFilePdf(String codiceFiscale, String codiceEnte,HashMap<String,String> oneriMap, boolean rate);
        
	OnereFattoreCalcolo selectFattoreCalcByDestUso (Long idOneriDestinazioneUso, String parametro1, String parametro2);
	List<OnereIncremento> selectOnereIncrListByCl( String classeIncremento);
//	List<OnereRataTotale> calcolaRate(BigDecimal totale, BigDecimal numRate, BigDecimal tassoInt);
//	BigDecimal calcolaFidejussione(BigDecimal totale, BigDecimal numRate, BigDecimal tassoInt);
	OnereCoefficiente selectOnereCoeffById(Long idOneriCoefficienti, String codEnte);
	OnereIncremento selectOnereIncrByCod(String codIncremento, String classeIncremento);
	
}
