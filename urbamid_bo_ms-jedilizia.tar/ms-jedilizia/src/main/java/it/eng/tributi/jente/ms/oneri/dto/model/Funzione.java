package it.eng.tributi.jente.ms.oneri.dto.model;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Funzione {
	
	protected Long idFunzione;
	protected String codFunzione;
	protected String descrizione;
	protected String tipoFunzione;
	protected String idFunzionePadre;
	protected Integer idApplicativo;
	protected List<Funzione> funzioniFiglie;

}
