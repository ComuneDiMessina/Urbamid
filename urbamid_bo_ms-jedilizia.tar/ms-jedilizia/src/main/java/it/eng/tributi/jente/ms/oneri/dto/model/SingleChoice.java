package it.eng.tributi.jente.ms.oneri.dto.model;

import it.arezzo.infor.jente.jadmin.service.util.Util;
import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class SingleChoice implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    protected String codice;
    protected String descrizione;

    public static SingleChoice getSingleChoice(OnereIncremento onereIncremento) {
        SingleChoice singleChoice=new SingleChoice();
        singleChoice.setCodice(onereIncremento.getCodIncremento());
        singleChoice.setDescrizione(onereIncremento.getDescrizione());
        return singleChoice;
    }
    
    public static SingleChoice getSingleChoice(OnereCoefficiente onereCoefficiente) {
        SingleChoice singleChoice=new SingleChoice();
        singleChoice.setCodice(onereCoefficiente.getCodCoefficiente());
        singleChoice.setDescrizione(onereCoefficiente.getDescrizione());
        return singleChoice;
    }    

//    public static OnereCoefficiente getOnereCoefficiente(SingleChoice onereResponse) {
//        return (OnereCoefficiente) Util.converti(onereResponse,OnereCoefficiente.class);
//    }
//    
//    public static SingleChoice getOnereCoefficienteResponse(OnereCoefficiente onereCoefficiente) {
//        return (SingleChoice) Util.converti(onereCoefficiente,SingleChoice.class);
//    }
//    
//    public static List<SingleChoice> getOnereCoefficienteResponseList(List<OnereCoefficiente> lista) {
//        return (List<SingleChoice>) Util.convertiLista(lista, SingleChoice.class);
//    }
//    
//    public static List<OnereCoefficiente> getOnereCoefficienteList(List<SingleChoice> lista) {
//        return (List<OnereCoefficiente>) Util.convertiLista(lista, OnereCoefficiente.class);
//    }
}
