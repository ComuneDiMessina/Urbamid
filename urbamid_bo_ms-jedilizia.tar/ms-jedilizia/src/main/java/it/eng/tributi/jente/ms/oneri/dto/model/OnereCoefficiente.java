package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class OnereCoefficiente implements Serializable {

	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;

	protected Long idOneriCoefficienti;
	protected String classeCoefficiente;
	protected String codCoefficiente;
	protected String descrizione;
	protected BigDecimal valore;
	protected String destUso;
	protected Boolean attivo;
        
        public static OnereCoefficiente onereCoefficienteUnitario(String codiceDestUso){
            OnereCoefficiente retval=new  OnereCoefficiente();
            retval.setValore(new BigDecimal(1));
            retval.setDestUso(codiceDestUso);
            retval.setAttivo(Boolean.TRUE);
            return retval;
        }

}
