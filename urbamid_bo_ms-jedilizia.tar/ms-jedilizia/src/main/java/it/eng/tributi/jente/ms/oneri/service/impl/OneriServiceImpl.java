package it.eng.tributi.jente.ms.oneri.service.impl;

import com.infor.jente.jutility.bean.InforSessionMaster;
import com.infor.jente.jutility.librerie.ParserSql;
import it.arezzo.infor.jente.jedilizia.proc.PEDPraticaEconomiciRateizzaService;
import it.arezzo.infor.jente.jedilizia.util.EdiliziaConstants;
import it.arezzo.infor.jente.jprocedimenti.service.dto.Economici;
import it.arezzo.infor.jente.jprocedimenti.service.dto.ListaEconomici;
import it.arezzo.infor.jente.jutility.UtilDate;
import it.arezzo.infor.jente.jutility.UtilString;
import it.arezzo.infor.jente.jworkflow.util.SiglePdfConstants;
import it.eng.tributi.jente.ms.commons.util.exception.GenericException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import it.eng.tributi.jente.ms.oneri.dto.model.IncrementoCaratteristica;
import it.eng.tributi.jente.ms.oneri.dto.model.IncrementoClasse;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereCoefficiente;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereCostruzioneDatiCalc;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereDestinazioneUso;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereFattoreCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereIncremento;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereUrbanizzazioneCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.OneriCostruzioneCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereResponse;
import it.eng.tributi.jente.ms.oneri.util.DizionarioConstant;
import it.eng.tributi.jente.ms.oneri.dao.impl.OneriDAO;
import it.eng.tributi.jente.ms.oneri.dto.model.CostoCostruzioneAbbattutoCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.Document;
import it.eng.tributi.jente.ms.oneri.dto.model.Esito;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereClasseMaggiorazione;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereDestinazioneCC;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereIncrementoServizio;
import it.eng.tributi.jente.ms.oneri.service.OneriService;
import it.eng.tributi.jente.ms.oneri.util.Utils;
import java.sql.Connection;
import java.util.ArrayList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
@Transactional(isolation = Isolation.READ_COMMITTED)
public class OneriServiceImpl extends AbstractServiceImpl implements OneriService {

    private static Logger logger = LoggerFactory.getLogger(OneriServiceImpl.class);

    @Autowired
    private OneriDAO oneriDAO;

//    @Override
//    public OneriModel calcolaOneri(OneriModel oneriModel) {
//        try {
//            OneriModel res = new OneriModel();
//            BigDecimal totPrimario = new BigDecimal(0);
//            BigDecimal totSecondario = new BigDecimal(0);
//            for (OnereResponse item : res.getTotOneriUrb()) {
//                totPrimario = totPrimario.add(item.getImportoPrimario());
//                totSecondario = totSecondario.add(item.getImportoSecondario());
//            }
//            res.getOnereUrbanizzazione().setTributo1(totPrimario);
//            res.getOnereUrbanizzazione().setTributo2(totSecondario);
//            return res;
//        } catch (Exception e) {
//            logger.error(e.getMessage());
//            throw e;
//        }
//    }
    public OnereResponse calcOneriUrbanizzazione(List<OnereUrbanizzazioneCalcolo> oneriUrb, HashMap<String, String> oneriMap, String codEnte, String tipoPagamento, boolean daPagareSubito) {
        OnereResponse totOn = new OnereResponse();
        Esito esito = new Esito();
        Esito.creaMessaggioOK(esito);
        totOn.setEsito(esito);

        try {
            for (OnereUrbanizzazioneCalcolo item : oneriUrb) {
                if (!(null == item.getIdOneriDestinazioneUso())) {
                    OnereDestinazioneUso destUso = oneriDAO.selectDestinazioneUso(item.getIdOneriDestinazioneUso());
                    if (null == destUso) {
                        throw new GenericException("Calcolo urbanizzazione - Destinazione d'uso non presente in DB (" + item.getIdOneriDestinazioneUso() + " )");
                    }
                    OnereFattoreCalcolo fattCalc = oneriDAO.selectFattoreCalcByDestUso(destUso.getIdOneriDestinazioneUso(), item.getParametro1(), item.getParametro2());
                    if (null == fattCalc) {
                        throw new GenericException("Calcolo urbanizzazione - Fattore calcolo  non presente in DB (" + destUso.getIdOneriDestinazioneUso() + "/" + item.getParametro1() + "/" + item.getParametro2() + ")");
                    }

                    BigDecimal oneriUrbanizzazione = new BigDecimal(0);
                    BigDecimal tariffaPrimaria = fattCalc.getTariffaPrimaria();
                    BigDecimal tariffaSecondaria = new BigDecimal(0);
                    if (fattCalc.getTariffaSecondaria() != null) {
                        tariffaSecondaria = fattCalc.getTariffaSecondaria();
                    }
                    BigDecimal tariffa = tariffaPrimaria.add(tariffaSecondaria).setScale(2, RoundingMode.HALF_DOWN);
                    addMap(oneriMap, DizionarioConstant.LABEL_OU_TARIFFA, tariffa + "");
                    oneriUrbanizzazione = item.getVolumeVuotoPerPieno().multiply(tariffa).setScale(2, RoundingMode.HALF_DOWN);
                    addMap(oneriMap, DizionarioConstant.LABEL_OU_TOTALE_ONERE, oneriUrbanizzazione + "");

                    String codiceOneriUrbanizzazione = UtilString.vbTrim(leggiProprieta(codEnte, DizionarioConstant.PROP_CODICE_ONERI_URBANIZZAZIONE));
                    if (codiceOneriUrbanizzazione.equals("")) {
                        throw new GenericException("Calcolo urbanizzazione - proprietà codice onere urbanizzazione mancante ");
                    }
                    if (Utils.daRateizzare(tipoPagamento, daPagareSubito)) {
                        calcolaRate(oneriMap, oneriUrbanizzazione, codiceOneriUrbanizzazione, codEnte);
                    } else {
                        addMap(oneriMap, SiglePdfConstants.PREFISSO_DATIECONOMICI + codiceOneriUrbanizzazione + "-0_" + SiglePdfConstants.ECO_IMPORTO, oneriUrbanizzazione + "");
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
            Esito.creaMessaggioKO(esito, "Eccezione nel calcolo onere urbanizzazione:" + e.getMessage());
            totOn.setEsito(esito);
        }
        return totOn;
    }

//    public OnereResponse calcOneriParcheggio(List<OneriParcheggiCalcolo> oneriParch, HashMap<String, String> oneriMap, String codEnte) {
//        OnereResponse totOn = new OnereResponse();
//        BigDecimal impOnere = new BigDecimal(0);
//        Esito esito = new Esito();
//        Esito.creaMessaggioOK(esito);
//        totOn.setEsito(esito);    
//        totOn.setMappaOneri(oneriMap);       
//        
//        try {
//            for (OneriParcheggiCalcolo item : oneriParch) {
//                if (!(null == item.getSulIncremento())) {
//                    OnereMonetizzazioneParcheggio monParch = oneriDAO.selectOnMonParchBySul(item.getSulIncremento());
//                    if (!(null == monParch) && !(null == monParch)) {
//                        BigDecimal parchDovuti = item.getSulIncremento().multiply(new BigDecimal(0.33)).setScale(2, RoundingMode.HALF_UP);
//                        BigDecimal parchNonRep = parchDovuti.subtract(item.getMqParchRep());
//                        if (parchNonRep.compareTo(new BigDecimal(0)) >= 1) {
//                            impOnere = impOnere.add(monParch.getImpMonetizzazione().multiply(parchNonRep));
//                        } else {
//                            impOnere = impOnere.add(new BigDecimal(0));
//                        }
//                    }
//                }
//            }
//        } catch (Exception e) {
//            logger.error(e.getMessage());
//            Esito.creaMessaggioKO(esito, "Eccezione nel calcolo costo costruzione");
//            totOn.setEsito(esito);
//        }
//        return totOn;
//    }
    private static void addMap(HashMap<String, String> map, String key, String value) {
        map.put(key, value);
    }

    private BigDecimal getCostoCostruzioneEdificio(BigDecimal costoCostruzioneFinale, BigDecimal sc, BigDecimal st, HashMap result) throws GenericException {
        BigDecimal costoCostruzioneEdificio = null;
        try {
            BigDecimal suptot = sc.add(st);
            costoCostruzioneEdificio = costoCostruzioneFinale.multiply(suptot).setScale(2, RoundingMode.HALF_DOWN);
            addMap(result, DizionarioConstant.LABEL_COSTO_COSTRUZIONE_EDIFICIO, costoCostruzioneEdificio + "");
        } catch (Exception e) {
            throw new GenericException("Eccezione nel calcolo Costo Costruzione Edificio");
        }
        return costoCostruzioneEdificio;
    }

    private BigDecimal getCostoCostruzioneFinale(OneriCostruzioneCalcolo oneriCostr, BigDecimal totIncr, HashMap result) throws GenericException {
        BigDecimal costoCostruzioneFinale = null;
        try {
            OnereDestinazioneCC onereDestinazioneUso = oneriDAO.selectDestinazioneCC(oneriCostr.getCostoCostruzioneAbbattutoCalcolo().getIdDestinazioneCC());
            if (null == onereDestinazioneUso) {
                throw new GenericException("Onere destinazione d'uso non presente in DB (" + oneriCostr.getCostoCostruzioneAbbattutoCalcolo().getIdDestinazioneCC() + ")");
            }
            //costoCostruzione = costo massimo mq edilizia agevelota [ATT_CCIMPA] 
            BigDecimal costoCostruzione = onereDestinazioneUso.getCostoCostruzione();
            addMap(result, DizionarioConstant.LABEL_COSTO_COSTRUZIONE, costoCostruzione.setScale(2, RoundingMode.HALF_DOWN) + "");

            // coefficienteRiduzione = coefficiente riduzione [ATT_PERCCMQ]
            // costoCostruzioneDecrementato = coefficiente riduzione *costo costruzione [ATT_CCMAG]   
            OnereCoefficiente onereCoefficiente = oneriDAO.selectOnereCoeffByCod(DizionarioConstant.ONERI_CODICE_COEFFICIENTE_RIDUZIONE, DizionarioConstant.ONERI_COEFFICIENTE_RIDUZIONE);
            if (null == onereCoefficiente) {
                throw new GenericException("Onere Coefficiente non presente in DB (" + DizionarioConstant.ONERI_CODICE_COEFFICIENTE_RIDUZIONE + "/" + DizionarioConstant.ONERI_COEFFICIENTE_RIDUZIONE + ")");
            }
            BigDecimal coefficienteRiduzione = onereCoefficiente.getValore();
            addMap(result, DizionarioConstant.LABEL_COEFFICIENTE_DECREMENTO, coefficienteRiduzione.setScale(2, RoundingMode.HALF_DOWN) + "");
            BigDecimal costoCostruzioneDecrementato = costoCostruzione.multiply(coefficienteRiduzione).setScale(2, RoundingMode.HALF_DOWN);
            addMap(result, DizionarioConstant.LABEL_COSTO_COSTRUZIONE_DECREMENTATO, costoCostruzioneDecrementato + "");

            // maggiorazione [ATT_CCMAG]
            OnereClasseMaggiorazione onereClasseMaggiorazione = oneriDAO.selectOnereClasseMaggByInt(totIncr);
            if (null == onereClasseMaggiorazione) {
                throw new GenericException("Percentuale maggiorazione non presente in DB (" + totIncr + ")");
            }
            addMap(result, DizionarioConstant.LABEL_CLASSE_MAGGIORAZIONE, onereClasseMaggiorazione.getClasseMagg());
            BigDecimal percMaggiorazione = onereClasseMaggiorazione.getValoreMagg();
            addMap(result, DizionarioConstant.LABEL_MAGGIORAZIONE, percMaggiorazione + "");

            BigDecimal maggiorazione = new BigDecimal(1).add(percMaggiorazione.divide(new BigDecimal(100), 10, RoundingMode.HALF_DOWN));

            costoCostruzioneFinale = costoCostruzioneDecrementato.multiply(maggiorazione).setScale(2, RoundingMode.HALF_DOWN);
            addMap(result, DizionarioConstant.LABEL_COSTO_COSTRUZIONE_MAGGIORATO, costoCostruzioneFinale + "");
        } catch (Exception e) {
            throw new GenericException("Eccezione nel calcolo Costo Costruzione Edificio Finale:" + e.getMessage());
        }
        return costoCostruzioneFinale;
    }

    private BigDecimal getSt(OneriCostruzioneCalcolo oneriCostr, HashMap result) throws GenericException {
        //saRagg = superficie sa ragguagliata [ATT_CCSARAG]
        //st = superficie totale non residenziale  [ATT_CCSTTOT] 
        BigDecimal st = null;
        try {

            if (null == oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiTuristicheCommerciali().getSulNettaNonResidenziale()) {
                oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiTuristicheCommerciali().setSulNettaNonResidenziale(new BigDecimal(0));
            }
            if (null == oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiTuristicheCommerciali().getSulAccessori()) {
                oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiTuristicheCommerciali().setSulAccessori(new BigDecimal(0));
            }

            BigDecimal saRagg = oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiTuristicheCommerciali().getSulAccessori().multiply(new BigDecimal(DizionarioConstant.ONERI_COEFF_ABBATTIMENTO_ACCESSORIO_NON_RESIDENZIALE)).setScale(2, RoundingMode.HALF_DOWN);
            st = oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiTuristicheCommerciali().getSulNettaNonResidenziale().add(saRagg);

            addMap(result, DizionarioConstant.LABEL_SARAGG, saRagg + "");
            addMap(result, DizionarioConstant.LABEL_ST, st + "");
        } catch (Exception e) {
            throw new GenericException("Eccezione nel calcolo Superficie Totale Non Residenziale");
        }
        return st;
    }

    private BigDecimal getSc(BigDecimal su, BigDecimal snr, HashMap result) throws GenericException {
        //snrRagg = superficie snr ragguagliata [ATT_CCSNRRAG]
        //sc = superficie complessiva  [ATT_CCSCTOT] 
        BigDecimal sc = null;
        try {
            BigDecimal snrRagg = snr.multiply(new BigDecimal(DizionarioConstant.ONERI_COEFF_ABBATTIMENTO_ACCESSORIO)).setScale(2, RoundingMode.HALF_DOWN);
            sc = su.add(snrRagg);

            addMap(result, DizionarioConstant.LABEL_SNRRAGG, snrRagg + "");
            addMap(result, DizionarioConstant.LABEL_SC, sc + "");
        } catch (Exception e) {
            throw new GenericException("Eccezione nel calcolo Superficie Complessiva Residenziale");
        }
        return sc;
    }

    private BigDecimal getSnr(OneriCostruzioneCalcolo oneriCostr, HashMap result) throws GenericException {
        BigDecimal snr = null;
        try {
            if (null == oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().getSulCantine()) {
                oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().setSulCantine(new BigDecimal(0));
            }
            if (null == oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().getSulAutorimesse()) {
                oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().setSulAutorimesse(new BigDecimal(0));
            }
            if (null == oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().getSulAndroni()) {
                oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().setSulAndroni(new BigDecimal(0));
            }
            if (null == oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().getSulBalconi()) {
                oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().setSulBalconi(new BigDecimal(0));
            }
            if (null == oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().getSulAutorimesseCollettive()) {
                oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().setSulAutorimesseCollettive(new BigDecimal(0));
            }

            //sulServizi = Snr (superfici servizi e accessori parte residenziale) [ATT_CCSNRTOT]
            snr = oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().getSulCantine().
                    add(oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().getSulAutorimesse().
                            add(oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().getSulAndroni().
                                    add(oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().getSulBalconi()).
                                    add(oneriCostr.getCoefficienteMaggiorazioneCalcolo().getDettaglioSuperficiAccessorie().getSulAutorimesseCollettive())));

            addMap(result, DizionarioConstant.LABEL_SNR, snr + "");
        } catch (Exception e) {
            throw new GenericException("Eccezione nel calcolo Superficie Netta Non Residenziale");
        }
        return snr;
    }

    private BigDecimal getSu(OneriCostruzioneCalcolo oneriCostr, HashMap result) throws GenericException {
        //sulAbitabile = SU (superficie utile abitabile residenziale) [ATT_CCSUTOT]
        BigDecimal su = new BigDecimal(0);
        try {
            if (oneriCostr.getCoefficienteMaggiorazioneCalcolo() != null
                    && oneriCostr.getCoefficienteMaggiorazioneCalcolo().getIncrementiClassi() != null
                    && !oneriCostr.getCoefficienteMaggiorazioneCalcolo().getIncrementiClassi().isEmpty()) {
                for (IncrementoClasse item : oneriCostr.getCoefficienteMaggiorazioneCalcolo().getIncrementiClassi()) {
                    if (!(null == item.getSulAlloggi())) {
                        su = su.add(item.getSulAlloggi());
                    }
                }
            }
            addMap(result, DizionarioConstant.LABEL_SU, su + "");
        } catch (Exception e) {
            throw new GenericException("Eccezione nel calcolo Superficie Utile Residenziale");
        }
        return su;
    }

    private BigDecimal getIncremento1(OneriCostruzioneCalcolo oneriCostr, BigDecimal su, HashMap result) throws GenericException {
        //incrL1 = i1  [ATT_CCINCR1]
        BigDecimal incrL1 = new BigDecimal(0);
        try {
            int i = 0;
            for (IncrementoClasse item : oneriCostr.getCoefficienteMaggiorazioneCalcolo().getIncrementiClassi()) {
                i = i + 1;
                BigDecimal rappSul;
                BigDecimal percIncr;
                BigDecimal perIncrClassiSup;
                if (!(null == item.getSulAlloggi()) && su.compareTo(new BigDecimal(0)) != 0) {
                    //rappSul = rapporto rispetto al totale SU [ATT_CCSUSUTOTX]
                    rappSul = item.getSulAlloggi().divide(su, 10, RoundingMode.HALF_UP);
                    addMap(result, DizionarioConstant.LABEL_RAPPORTORISPETTOSU_PREFIX + i, rappSul.setScale(2, RoundingMode.HALF_DOWN) + "");
                    OnereIncremento onereIncr = oneriDAO.selectOnereIncrByCod(item.getCodIncremento(), item.getIdClasseSul());
                    if (null == onereIncr) {
                        throw new GenericException("Onere Incremento non presente in DB (" + item.getCodIncremento() + "/" + item.getIdClasseSul() + ")");
                    }
                    percIncr = onereIncr.getPercIncremento();
                    //perIncrClassiSup = % Incremento per classi di superficie [ATT_CCINCR1_X]
                    perIncrClassiSup = (rappSul.multiply(percIncr)).setScale(2, RoundingMode.HALF_UP);
                    addMap(result, DizionarioConstant.LABEL_PERC_INCREMENTO_CLASSI_SUP_PREFIX + i, perIncrClassiSup + "");
                    incrL1 = incrL1.add(perIncrClassiSup);
                } else {
                    addMap(result, DizionarioConstant.LABEL_RAPPORTORISPETTOSU_PREFIX + i, "0.00" + "");
                    addMap(result, DizionarioConstant.LABEL_PERC_INCREMENTO_CLASSI_SUP_PREFIX + i, "0.00" + "");
                }

            }
            addMap(result, DizionarioConstant.LABEL_INCREMENTO1, incrL1 + "");
        } catch (Exception e) {
            throw new GenericException("Eccezione nel calcolo Incremento 1:" + e.getMessage());
        }
        return incrL1;
    }

    private BigDecimal getIncremento2(BigDecimal snrDivisoSu, HashMap result) throws GenericException {

        //incrL2 = i2 [ATT_CCINCR2]
        BigDecimal incrL2 = new BigDecimal(0);
        try {
            if (snrDivisoSu.compareTo(new BigDecimal(0)) > 0) {
                OnereIncrementoServizio onereIncrementoServizio = oneriDAO.selectOnereIncrServByInt(snrDivisoSu);
                if (null == onereIncrementoServizio) {
                    throw new GenericException("Onere Incremento servizio non presente in DB (" + snrDivisoSu + ")");
                }
                addMap(result, DizionarioConstant.LABEL_INCREMENTO2_CASO, onereIncrementoServizio.getIdIncrementoServ() + "");

                incrL2 = onereIncrementoServizio.getPercIncremento();
            }

            addMap(result, DizionarioConstant.LABEL_INCREMENTO2, incrL2 + "");
        } catch (Exception e) {
            throw new GenericException("Eccezione nel calcolo Incremento 2:" + e.getMessage());
        }
        return incrL2;
    }

    private BigDecimal getIncremento3(OneriCostruzioneCalcolo oneriCostr, HashMap result) throws GenericException {

        //incrL2 = i3 [ATT_CCINCR3]
        BigDecimal incrL3 = new BigDecimal(0);
        int i = 1;
        try {
            for (IncrementoCaratteristica item : oneriCostr.getCoefficienteMaggiorazioneCalcolo().getIncrementiCaratt()) {
                if (!(null == item.getCodIncremento()) && !item.getCodIncremento().equals("")) {
                    OnereIncremento onereIncremento = oneriDAO.selectOnereIncrByCod(item.getCodIncremento(), item.getClasseIncremento());
                    if (null == onereIncremento) {
                        throw new GenericException("Onere incremento non presente in DB (" + item.getCodIncremento() + "/" + item.getClasseIncremento() + ")");
                    }
                    incrL3 = incrL3.add(onereIncremento.getPercIncremento());
                    i = i + 1;
                }
            }
            if (i > 6) {
                throw new GenericException("Eccezione nel calcolo Incremento 3: troppi incrementi, possono essere al massimo 5");
            }
            addMap(result, DizionarioConstant.LABEL_INCREMENTO3_CASO, "0" + i);
            addMap(result, DizionarioConstant.LABEL_INCREMENTO3, incrL3 + "");
        } catch (Exception e) {
            throw new GenericException("Eccezione nel calcolo Incremento 3:" + e.getMessage());
        }
        return incrL3;

    }

    private BigDecimal getIncrementoTotale(OneriCostruzioneCalcolo oneriCostr, BigDecimal su, BigDecimal snr, HashMap result) throws GenericException {

        //incrL1 = i1  [ATT_CCINCR1]
        BigDecimal incrL1 = getIncremento1(oneriCostr, su, result);

        //incrServ = Snr/Su*100 [ATT_CCSNR-SU]
        BigDecimal snrDivisoSu = snr.compareTo(new BigDecimal(0))==0 ? new BigDecimal(0) : (su.compareTo(new BigDecimal(0))==0 ? new BigDecimal(0) : (snr.divide(su, 10, RoundingMode.HALF_DOWN)).multiply(new BigDecimal(100)));
        snrDivisoSu = snrDivisoSu.setScale(2, RoundingMode.HALF_DOWN);
        addMap(result, DizionarioConstant.LABEL_SNR_DIVISO_SU, snrDivisoSu + "");

        BigDecimal incrL2 = getIncremento2(snrDivisoSu, result);
        BigDecimal incrL3 = getIncremento3(oneriCostr, result);

        //totIncr = i [ATT_CCINCRTOT]
        BigDecimal totIncr = incrL1.add(incrL2).add(incrL3);
        addMap(result, DizionarioConstant.LABEL_INCREMENTOTOT, totIncr + "");

        return totIncr;
    }

    private BigDecimal getAliquotaC(CostoCostruzioneAbbattutoCalcolo costoCostruzioneAbbattutoCalcolo, HashMap result) throws GenericException {
        OnereCoefficiente destinazioneObject = oneriDAO.selectOnereCoeffByCod(costoCostruzioneAbbattutoCalcolo.getOnereAliquotaCalcolo().getCodiceDestinazione(), DizionarioConstant.ONERI_CLASS_DESTINAZIONE);
        if (null == destinazioneObject) {
            throw new GenericException("Aliquota C - Onere coefficiente  non presente in DB (" + costoCostruzioneAbbattutoCalcolo.getOnereAliquotaCalcolo().getCodiceDestinazione() + ")");
        }
        BigDecimal aliquotaC = destinazioneObject.getValore();
        addMap(result, DizionarioConstant.LABEL_ALIQUOTA_C, aliquotaC + "");

        return aliquotaC;
    }

    private BigDecimal getAliquotaB(CostoCostruzioneAbbattutoCalcolo costoCostruzioneAbbattutoCalcolo, HashMap result) throws GenericException {
        OnereCoefficiente destinazioneObject = oneriDAO.selectOnereCoeffByCod(costoCostruzioneAbbattutoCalcolo.getOnereAliquotaCalcolo().getCodiceTipologia(), DizionarioConstant.ONERI_CLASS_TIPOLOGIA);
        if (null == destinazioneObject) {
            throw new GenericException("Aliquota B - Onere coefficiente non presente in DB (" + costoCostruzioneAbbattutoCalcolo.getOnereAliquotaCalcolo().getCodiceTipologia() + ")");
        }
        BigDecimal aliquotaB = destinazioneObject.getValore();
        addMap(result, DizionarioConstant.LABEL_ALIQUOTA_B, aliquotaB + "");

        return aliquotaB;
    }

    private BigDecimal getAliquotaA(BigDecimal totIncr, HashMap result) throws GenericException {
        BigDecimal aliquotaA = null;
        try {
            OnereClasseMaggiorazione onereClasseMaggiorazione = oneriDAO.selectOnereClasseMaggByInt(totIncr);
            if (null == onereClasseMaggiorazione) {
                throw new GenericException("Onere classe maggiorazione non presente in DB (" + totIncr + ")");
            }
            Long idClasseEdificio = onereClasseMaggiorazione.getIdClasseMagg();
            String codClasseEdificio = ("00" + idClasseEdificio + "").substring((idClasseEdificio + "").length());
            OnereCoefficiente classeEdificioObject = oneriDAO.selectOnereCoeffByCod(codClasseEdificio, DizionarioConstant.ONERI_CLASS_CARATTERISTICHE);
            if (null == classeEdificioObject) {
                throw new GenericException("Classe edificio non presente in DB (" + codClasseEdificio + "/" + DizionarioConstant.ONERI_CLASS_CARATTERISTICHE + ")");
            }
            // aliquotaA = aliquota A [ATT_CCCARA]
            aliquotaA = classeEdificioObject.getValore();
            addMap(result, DizionarioConstant.LABEL_ALIQUOTA_A, aliquotaA + "");
        } catch (Exception e) {
            throw new GenericException("Eccezione nel calcolo Aliquota A:" + e.getMessage());
        }
        return aliquotaA;
    }

    private BigDecimal getAliquotaTotale(BigDecimal totIncr, OneriCostruzioneCalcolo oneriCostr, HashMap result) throws GenericException {

        BigDecimal aliquotaA = getAliquotaA(totIncr, result);

        CostoCostruzioneAbbattutoCalcolo costoCostruzioneAbbattutoCalcolo = oneriCostr.getCostoCostruzioneAbbattutoCalcolo();
        BigDecimal aliquotaB = getAliquotaB(costoCostruzioneAbbattutoCalcolo, result);
        BigDecimal aliquotaC = getAliquotaC(costoCostruzioneAbbattutoCalcolo, result);

        BigDecimal aliquotaTotale = aliquotaA.add(aliquotaB.add(aliquotaC));
        addMap(result, DizionarioConstant.LABEL_ALIQUOTA_TOTALE, aliquotaTotale + "");
        return aliquotaTotale;
    }

    private BigDecimal getContributoDovuto(BigDecimal aliquotaTotale, BigDecimal costoCostruzioneFinale, HashMap result) throws GenericException {
        BigDecimal contributoDovuto = null;
        try {
            BigDecimal aliquota = aliquotaTotale.divide(new BigDecimal(100), 10, RoundingMode.HALF_DOWN);
            contributoDovuto = aliquota.multiply(costoCostruzioneFinale).setScale(2, RoundingMode.HALF_DOWN);
            addMap(result, DizionarioConstant.LABEL_CONTRIBUTO_DOVUTO, contributoDovuto + "");
            addMap(result, DizionarioConstant.LABEL_ECONOMICO_CC, contributoDovuto + "");
        } catch (Exception e) {
            throw new GenericException("Eccezione nel calcolo Contributo Dovuto");
        }
        return contributoDovuto;
    }

    @Override
    public OnereResponse calcOneriCostruzione(OneriCostruzioneCalcolo oneriCostr, HashMap<String, String> oneriMap, String codEnte, String tipoPagamento, boolean daPagareSubito) {
        OnereResponse totOn = new OnereResponse();
        Esito esito = new Esito();
        Esito.creaMessaggioOK(esito);
        totOn.setEsito(esito);
        try {
            Map<String, OnereCostruzioneDatiCalc> mappaDatiCalc = new HashMap<>();
            if (!(null == oneriCostr.getCostoCostruzioneAbbattutoCalcolo())) {
                //sulAbitabile = SU (superficie utile abitabile residenziale) [ATT_CCSUTOT]
                BigDecimal su = getSu(oneriCostr, oneriMap);
                if (mappaDatiCalc.containsKey(DizionarioConstant.ONERI_COSTR_DEST_USO_$RES)
                        && mappaDatiCalc.get(DizionarioConstant.ONERI_COSTR_DEST_USO_$RES).getSupTot().compareTo(new BigDecimal(0)) == 1
                        && su.compareTo(new BigDecimal(0)) == 0) {
                    Esito.creaMessaggioKO(esito, "L'Onere presenta superfici residenziali di cui non sono state indicate le caratterische");
                    totOn.setEsito(esito);
                    return totOn;
                }

                BigDecimal snr = getSnr(oneriCostr, oneriMap);

                BigDecimal sc = getSc(su, snr, oneriMap);

                BigDecimal st = getSt(oneriCostr, oneriMap);

                BigDecimal totIncr = getIncrementoTotale(oneriCostr, su, snr, oneriMap);

                BigDecimal costoCostruzioneFinale = getCostoCostruzioneFinale(oneriCostr, totIncr, oneriMap);

                BigDecimal costoCostruzioneEdificio = getCostoCostruzioneEdificio(costoCostruzioneFinale, sc, st, oneriMap);

                BigDecimal aliquotaTotale = getAliquotaTotale(totIncr, oneriCostr, oneriMap);

                BigDecimal totaleCostiCostruzione = getContributoDovuto(aliquotaTotale, costoCostruzioneEdificio, oneriMap);

                String codiceOneriCostruzione = UtilString.vbTrim(leggiProprieta(codEnte, DizionarioConstant.PROP_CODICE_COSTO_COSTRUZIONE));
                if (codiceOneriCostruzione.equals("")) {
                    throw new GenericException("Calcolo urbanizzazione - proprietà codice costo costruzione mancante ");
                }
                if (Utils.daRateizzare(tipoPagamento, daPagareSubito)) {
                    calcolaRate(oneriMap, totaleCostiCostruzione, codiceOneriCostruzione, codEnte);
                } else {
                    addMap(oneriMap, SiglePdfConstants.PREFISSO_DATIECONOMICI + codiceOneriCostruzione + "-0_" + SiglePdfConstants.ECO_IMPORTO, totaleCostiCostruzione + "");
                }

            } else {
                logger.error("Oggetto Costo Costruzione Abbattuto Calcolo vuoto");
                Esito.creaMessaggioKO(esito, "Oggetto Costo Costruzione Abbattuto Calcolo vuoto");
                totOn.setEsito(esito);
            }

        } catch (GenericException e) {
            logger.error(e.getMessage());
            Esito.creaMessaggioKO(esito, e.getMessage());
            totOn.setEsito(esito);
        }

        return totOn;
    }

    public Document getFilePdf(String codiceFiscale, String codiceEnte, HashMap<String, String> oneriMap, boolean rate) {
        Utils utils = new Utils();
        Document result = null;
        try {
            result = Utils.setDocument(utils.riempiModelloBase(codiceFiscale, codiceEnte, oneriMap, tempPath, flussiPath, rate));
        } catch (Exception ex) {
            String errore = "Errore nella formazione pdf:" + ex.getMessage();
            logger.error(errore);
        }
        return result;
    }
//    @Override
//    public List<ProcedimentoOnereParchSul> selectProcOnereParchSulByIdProc(Long idProcedimento) {
//        return oneriDAO.selectProcOnereParchSulByIdProc(idProcedimento);
//    }

    @Override
    public OnereFattoreCalcolo selectFattoreCalcByDestUso(Long idOneriDestinazioneUso, String parametro1, String parametro2) {
        return oneriDAO.selectFattoreCalcByDestUso(idOneriDestinazioneUso, parametro1, parametro2);
    }

    @Override
    public List<OnereIncremento> selectOnereIncrListByCl(String classeIncremento) {
        return oneriDAO.selectOnereIncrListByCl(classeIncremento);
    }

    @Override
    public OnereIncremento selectOnereIncrByCod(String codIncremento, String classeIncremento) {
        return oneriDAO.selectOnereIncrByCod(codIncremento, classeIncremento);
    }

    public OnereResponse calcolaRate(HashMap<String, String> oneriMap, BigDecimal importo, String codiceOnere, String codEnte) {
        Connection conn = null;
        Esito esito = new Esito();
        esito.creaMessaggioOK(esito);
        OnereResponse onereResponse = new OnereResponse();
        onereResponse.setEsito(null);
        try {
            InforSessionMaster session = settaSessione(codEnte);
            conn = getConnessione(session, EdiliziaConstants.CODICE_PROCEDURA_EDILZIA, codEnte);
            if (conn == null) {
                throw new GenericException("Errore, riprovare piu' tardi");
            } else {
                logger.debug("Aperta Connessione");
            }

            List<Economici> listEconomico = new ArrayList();
            Economici economico = new Economici();
            economico.setDato(codiceOnere);
            economico.setImportoDovuto(importo + "");
            economico.set_selezionato("S");
            listEconomico.add(economico);
            PEDPraticaEconomiciRateizzaService praticaDatiEconomiciService = new PEDPraticaEconomiciRateizzaService(session, conn);
            ListaEconomici listaEconomici = praticaDatiEconomiciService.calcolaRateEconomici(UtilDate.prendiData(), listEconomico);
            if (session.getTipoErrore().equals("E") && !UtilString.vbTrim(session.getErrore()).equals("")) {
                logger.error(UtilString.vbTrim(session.getErrore()));
                esito.creaMessaggioKO(esito, "Non è stata trovata la rateizzazione dell'onere " + codiceOnere + ":" + UtilString.vbTrim(session.getErrore()));
            } else {
                if (listaEconomici != null && listaEconomici.getListaEconomici() != null
                        && !listaEconomici.getListaEconomici().isEmpty()) {
                    int i = 1;
                    BigDecimal totaleFide = new BigDecimal(0);
                    for (Economici rata : listaEconomici.getListaEconomici()) {
                        addMap(oneriMap, SiglePdfConstants.PREFISSO_DATIECONOMICI + codiceOnere + "-" + i + "_" + SiglePdfConstants.ECO_IMPORTO, rata.getImportoDovuto());
                        addMap(oneriMap, SiglePdfConstants.PREFISSO_DATIECONOMICI + codiceOnere + "-" + i + "_" + SiglePdfConstants.ECO_DATA, UtilDate.giraDataGMA(rata.getDataDato()));
                        if (!rata.getDataDato().equals(UtilDate.prendiData())) {
                            totaleFide = totaleFide.add(new BigDecimal(rata.getImportoDovuto())).setScale(2, RoundingMode.HALF_DOWN);
                        }
                        i = i + 1;
                    }
                    calcolaFidejussione(oneriMap, totaleFide, codiceOnere, codEnte);
                } else {
                    esito.creaMessaggioKO(esito, "Non è stata trovata la rateizzazione dell'onere " + codiceOnere);
                }
            }
        } catch (Exception ex) {
            logger.error(ex.getMessage());
            esito.creaMessaggioKO(esito, "Eccezione nel calcolo rate");
            throw new GenericException(ex.getMessage(), ex);
        } finally {
            logger.debug("Chiusa Connessione");
            ParserSql.closeSql(conn);
        }

        return onereResponse;
    }

    private void calcolaFidejussione(HashMap<String, String> oneriMap, BigDecimal totale, String codiceOnere, String codEnte) {

        if (totale.compareTo(new BigDecimal(0)) != 0) {
            addMap(oneriMap, SiglePdfConstants.PREFISSO_FIDEIUSSIONI + codiceOnere + "-1" + "_" + SiglePdfConstants.FIDE_IMPORTO, totale.add(totale.divide(new BigDecimal(3), 10, RoundingMode.HALF_DOWN)).setScale(2, RoundingMode.HALF_DOWN) + "");
        }
        else{
             addMap(oneriMap, SiglePdfConstants.PREFISSO_FIDEIUSSIONI + codiceOnere + "-1" + "_" + SiglePdfConstants.FIDE_IMPORTO, "0.00");           
        }
    }

//    @Override
//    public List<OnereCostruzione> selectOneriCostruzione(Long idProcedimento) {
//        // TODO Auto-generated method stub
//        return null;
//    }
//
//    @Override
//    public OnereResponse verifOneriUrbanizzazione(OneriCostruzioneCalcolo oneriCostr, BigDecimal coeffAbb,
//            BigDecimal sulAbitInf2000, BigDecimal supTotCommTur, String codEnte) {
//        // TODO Auto-generated method stub
//        return null;
//    }
//
//    @Override
//    public OnereResponse verifOneriCostruzione(List<OnereUrbanizzazioneCalcolo> oneriUrb, String codEnte) {
//        // TODO Auto-generated method stub
//        return null;
//    }
//    @Override
//    public OnereResponse verifOneriParcheggio(List<OneriParcheggiCalcolo> oneriParch, String codEnte) {
//        // TODO Auto-generated method stub
//        return null;
//    }
//
//    @Override
//    public List<ProcedimentoOnereCostrSul> selectProcOnereCostrSulByIdProc(Long idProcedimento) {
//        // TODO Auto-generated method stub
//        return null;
//    }
//
//    @Override
//    public List<ProcedimentoOnereUrbSul> selectProcOnereUrbSulByIdProc(Long idProcedimento) {
//        // TODO Auto-generated method stub
//        return null;
//    }
    @Override
    public OnereCoefficiente selectOnereCoeffById(Long idOneriCoefficienti, String codEnte) {
        return oneriDAO.selectOnereCoeffById(idOneriCoefficienti, codEnte);
    }

//  public double getFidejussione(int rate) {
//  double d1 = (getTotaleUrbanizzazione() + getTotaleCostruzione()) * (rate - 1) / rate;
//  double gg = 0d;
//  if (rate == 4) {
//      gg = 730d;
//  } else if (rate == 5) {
//      gg = 912.5d;
//  } else if (rate == 6) {
//      gg = 1095d;
//  }
//  double d2 = gg / 365d * d1 * (interessi / 100);
//  double fdj = d1 + d2;
//  return fdj;
//}
}
