package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import it.eng.tributi.jente.ms.oneri.dto.api.OnereParcheggioApi;
import it.eng.tributi.jente.ms.oneri.dto.db.OnereParcheggioDB;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OnereParcheggio implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriParch;
	protected BigDecimal mqSulIncr;
	protected BigDecimal mqParchRep;
	protected BigDecimal costo;
	protected Date rowTsMod;
	
	public int hashKey() {
		final int prime = 31;
		int result = 0;
		result = prime * result + ((idOneriParch == null) ? 0 : idOneriParch.hashCode());
		return result;
	}
	
	public OnereParcheggioDB getDBDTO() {
		return OnereParcheggioDB.builder()
		.idOneriParch(idOneriParch)
		.mqSulIncr(mqSulIncr)
		.mqParchRep(mqParchRep)
		.costo(costo)
		.rowTsMod(rowTsMod)
		.build();
	}

	public static List<OnereParcheggioApi> linkOnereParcheggioeApiFromModel(List<OnereParcheggio> items){
		 ArrayList<OnereParcheggioApi> links = new ArrayList<>();
	        for (OnereParcheggio item : items) {
	        	OnereParcheggioApi link = OnereParcheggioApi.builder()
	        			.idOneriParch(item.getIdOneriParch())
	        			.mqSulIncr(item.getMqSulIncr())
	        			.mqParchRep(item.getMqParchRep())
	        			.costo(item.getCosto())
	        			.build();
	            links.add(link);
	        }
	        return links;
	}

	public static List<OneriParcheggiCalcolo> getOneriParchCalcoloFromOneriParch(List<OnereParcheggio> items){
		 ArrayList<OneriParcheggiCalcolo> links = new ArrayList<>();
	        for (OnereParcheggio item : items) {
	        	OneriParcheggiCalcolo link = OneriParcheggiCalcolo.builder()
	        			.sulIncremento(item.getMqSulIncr())
	        			.mqParchRep(item.getMqParchRep())
	        			.build();
	            links.add(link);
	        }
	        return links;
	}

}
