package it.eng.tributi.jente.ms.oneri.configuration;

import static springfox.documentation.builders.PathSelectors.regex;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.UiConfiguration;
import springfox.documentation.swagger.web.UiConfigurationBuilder;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@ConditionalOnExpression("${application.swagger.enabled:true} and ${application.swagger.specific:false}")
public class SwaggerConfig extends WebMvcConfigurationSupport {

    @Value("${spring.application.name}")
    private String  applicationName;
    
    @Autowired
    BuildProperties buildProperties;
    

    @Bean
    public Docket JOneriApi() {
        return new Docket(DocumentationType.SWAGGER_2)
        		.groupName("JOneriApi")
        		.useDefaultResponseMessages(false)
                .select()
                .apis(RequestHandlerSelectors.basePackage("it.eng.tributi.jente.ms.oneri.ws"))
                .paths(regex("/api/argo/.*"))
                .build()
                .apiInfo(metaData());
    }
    
//    @Bean
//    public Docket JOneriMobileApi() {
//        return new Docket(DocumentationType.SWAGGER_2)
//        		.groupName("JOneriMobileApi")
//        		.useDefaultResponseMessages(false)
//                .select()
//                .apis(RequestHandlerSelectors.basePackage("it.arezzo.infor.jente.microservices.backend.controller"))
//                .paths(regex("/api/mobile.*"))
//                .build()
//                .apiInfo(metaDataMobile());
//    }
//    

    @Bean
    UiConfiguration uiConfig() {
        return UiConfigurationBuilder.builder()
            .displayRequestDuration(true)
            .validatorUrl("")
            .build();
    }
    
    private ApiInfo metaData() {
        return new ApiInfoBuilder()
                .title("JOneri ARGO API")
                .description("\"JOneri REST API per ARGO\"")
                .version("1.0.0")
                .license("Apache License Version 2.0")
                .licenseUrl("https://www.apache.org/licenses/LICENSE-2.0\"")
                .contact(
                        new Contact("JOneri ARGO Backend",
                                "http://www.municipia.eng.it/",
                                "municipia@eng.it")).build();
    }

//    private ApiInfo metaDataMobile() {
//        return new ApiInfoBuilder()
//                .title("jOneri Mobile REST API")
//                .description("\"JOneri REST API per le APP Mobile\"")
//                .version("1.0.0")
//                .license("Apache License Version 2.0")
//                .licenseUrl("https://www.apache.org/licenses/LICENSE-2.0\"")
//                .contact(
//                        new Contact("JOneri Mobile Backend",
//                                "http://www.municipia.eng.it/",
//                                "municipia@eng.it")).build();
//    }
//

    @Override
    protected void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("swagger-ui.html").addResourceLocations(
                "classpath:/META-INF/resources/");

        registry.addResourceHandler("/webjars/**").addResourceLocations(
                "classpath:/META-INF/resources/webjars/");
    }
}