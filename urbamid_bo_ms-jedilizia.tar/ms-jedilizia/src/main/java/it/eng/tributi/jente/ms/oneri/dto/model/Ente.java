package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Ente implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idEnte;
	protected String nome;
	protected String descrizione;
	protected Date dataIni;
	protected Date dataFine;
	protected Long attivo;
	protected String indirizzo;
	protected String pec;
	protected String comune;
	protected Long suap;
	protected Long sue;
	protected String codEnteSem;
	
}
