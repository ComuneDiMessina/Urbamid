package it.eng.tributi.jente.ms.oneri.dto.db;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class DBOrmBase implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String STATUS_INS= "I";
	public static final String STATUS_MOD= "U";
	public static final String STATUS_DEL= "D";
	
	
	protected String rowStatus;
	
	public boolean isInsert() {
		return STATUS_INS.equalsIgnoreCase(rowStatus);
	}
	
	public boolean isUpdate() {
		return STATUS_MOD.equalsIgnoreCase(rowStatus);
	}
	
	public boolean isDelete() {
		return STATUS_DEL.equalsIgnoreCase(rowStatus);
	}
	
	public void setInsertStatus() {
		rowStatus = STATUS_INS;
	}
	
	public void setUpdateStatus() {
		rowStatus = STATUS_MOD;
	}
	
	public void setDeleteStatus() {
		rowStatus = STATUS_DEL;
	}
}
