package it.eng.tributi.jente.ms.oneri.ws;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import it.eng.tributi.jente.ms.commons.util.controller.BaseController;
import it.eng.tributi.jente.ms.oneri.dto.model.InputList;
import it.eng.tributi.jente.ms.oneri.dto.model.MultipleChoice;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereCoefficienteResponse;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereResponse;
import it.eng.tributi.jente.ms.oneri.dto.model.SingleChoiceList;
import it.eng.tributi.jente.ms.oneri.service.api.OneriApiService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestHeader;

@Api(value="Oneri",tags= {"Calcolo Oneri"})
@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = { "${application.jwt.context-path:/jwt}/api/oneri" })
public class OneriControllerApi extends BaseController {
	
	@Autowired 
	protected OneriApiService oneriApiService;
	
	@ApiOperation(value = "Calcola Oneri", notes = "Funzione per il calcolo degli oneri di costruzione, urbanizzazione")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
	@RequestMapping(path = "/calcolaOneri", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST, headers="Accept=application/json")
	public ResponseEntity<?> calcolaOneri(
               @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
                @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte,                
                @RequestBody InputList inputList) {
                OnereResponse risposta = oneriApiService.calcolaOneriApi(getJwtUser().getCodFiscale(),inputList,codEnte);
                 ResponseEntity<?> responseEntity = new ResponseEntity<>(risposta, HttpStatus.OK);
		return responseEntity;
	}
	
	
//	
//	@ApiOperation(value = "Dizionario Tabella Oneri Maggiorazioni", notes = "Funzione per il recupero della lista di maggiornazioni")
//	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
//	@RequestMapping(path = "/oneriMaggiorazioniOneri", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
//	public List<OnereClasseMaggiorazione> oneriMaggiorazioni(
//           @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
//            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte        ) {
//		return oneriApiService.selectOnereClasseMaggList(codEnte);
//	}
//	
//	
//	@ApiOperation(value = "Dizionario Tabella Destinazione USO ", notes = "Funzione per il recupero della lista delle Destinazioni Uso")
//	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
//	@RequestMapping(path = "/oneriDestinazioniUso", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
//	public List<OnereDestinazioneUso> selectDestinazioneUsoList(
//           @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
//            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte        ) {
//		return oneriApiService.selectDestinazioneUsoList(codEnte);
//	}
//	
//	@ApiOperation(value = "Dizionario Tabella Coefficienti ", notes = "Funzione per il recupero della lista dei Coefficienti")
//	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
//	@RequestMapping(path = "/oneriCoefficienti",  produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
//	public List<OnereCoefficiente>  selectOnereCoeffList(
//            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
//            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte) {
//                return oneriApiService.selectOnereCoeffList(codEnte);
//	}
        
	@ApiOperation(value = "Dizionario Tabella Coefficienti filtrato per classe", notes = "Funzione per il recupero della lista dei Coefficienti filtrato per classe")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
	@RequestMapping(path = "/oneriCoefficientiClasse",  produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
	public List<OnereCoefficienteResponse>  selectOnereCoeffListByClasse(
            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte,
            @ApiParam(value = "Classe", required = true) @RequestHeader(value = "CLASSE", required = true) String codClasse
            ) {
                return OnereCoefficienteResponse.getOnereCoefficienteResponseList(oneriApiService.selectOnereCoeffListByClasse(codEnte, codClasse));
	}       
        
	@ApiOperation(value = "Dizionario Classi Superficie", notes = "Funzione per il recupero della lista delle Classi Superficie")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
	@RequestMapping(path = "/classiSuperficie",  produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
	public List<MultipleChoice>  selectClassiSuperficie(
            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte
            ) {
                return oneriApiService.selectClassiSuperficieList(codEnte);
	}      
        
 	@ApiOperation(value = "Dizionario Superfici Residenziali", notes = "Funzione per il recupero della lista delle Superfici Residenziali")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
	@RequestMapping(path = "/superficiResidenziali",  produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
	public List<MultipleChoice>  selectSuperficiResidenziali(
            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte
            ) {
                return oneriApiService.selectSuperficiResidenziali(codEnte);
	}             
        
  	@ApiOperation(value = "Dizionario Caratteristiche Particolari", notes = "Funzione per il recupero della lista delle Caratteristiche Particolari")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
	@RequestMapping(path = "/caratteristicheParticolari",  produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
	public List<MultipleChoice>  selectCaratteristicheParticolari(
            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte
            ) {
                return oneriApiService.selectCaratteristicheParticolari(codEnte);
	}             
               

  	@ApiOperation(value = "Dizionario Tipologia Edificio", notes = "Funzione per il recupero della lista delle Tipologia Edificio")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
	@RequestMapping(path = "/tipologiaEdificio",  produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
	public SingleChoiceList  selectTipologiaEdificio(
            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte
            ) {
                return oneriApiService.selectTipologiaEdificio(codEnte);
	}                  
        
  	@ApiOperation(value = "Dizionario Destinazione", notes = "Funzione per il recupero della lista Destinazione")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
	@RequestMapping(path = "/destinazione",  produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
	public SingleChoiceList  selectDestinazione(
            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte
            ) {
                return oneriApiService.selectDestinazione(codEnte);
	}               
        
  	@ApiOperation(value = "Dizionario Zona", notes = "Funzione per il recupero della lista delle Zona")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
	@RequestMapping(path = "/zona",  produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
	public SingleChoiceList  selectZona(
            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte
            ) {
                return oneriApiService.selectZona(codEnte);
	}    
        
  	@ApiOperation(value = "Dizionario Zona PRG", notes = "Funzione per il recupero della lista Zona PRG")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
	@RequestMapping(path = "/zonaPRG",  produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
	public SingleChoiceList  selectZonaPRG(
            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte
            ) {
                return oneriApiService.selectZonaPRG(codEnte);
	}   
        
    	@ApiOperation(value = "Dizionario Tipo Domanda", notes = "Funzione per il recupero della lista Tipo Domanda")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
	@RequestMapping(path = "/tipoDomanda",  produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
	public SingleChoiceList  selectTipoDomanda(
            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte
            ) {
                return oneriApiService.selectTipoDomanda(codEnte);
	}      
        
    	@ApiOperation(value = "Dizionario Tipo Pagamento", notes = "Funzione per il recupero della lista Tipo Pagamento")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
	@RequestMapping(path = "/tipoPagamento",  produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
	public SingleChoiceList  selectTipoPagamento(
            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte
            ) {
                return oneriApiService.selectTipoPagamento(codEnte);
	}             
        
//	
//	@ApiOperation(value = "Dizionario Tabella Incrementi ", notes = "Funzione per il recupero della lista degli Incrementi")
//	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
//	@RequestMapping(path = "/oneriIncrementi", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
//	public List<OnereIncremento> selectOnereIncrList(
//           @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
//            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte        ) {
//		return oneriApiService.selectOnereIncrList(codEnte);
//	}
//	
//	@ApiOperation(value = "Dizionario Tabella Incrementi ", notes = "Funzione per il recupero della lista degli Incrementi")
//	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
//	@RequestMapping(path = "/oneriIncrementiServizi", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
//	public List<OnereIncrementoServizio> selectOnereIncrServList(
//            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
//            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte        ) {
//		return oneriApiService.selectOnereIncrServList(codEnte);
//	}
//	
//	@ApiOperation(value = "Dizionario Tabella Oneri Monetizzazione", notes = "Funzione per il recupero della lista degli Oneri Monetizzazione")
//	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid ID supplied"), @ApiResponse(code = 404, message = "") })
//	@RequestMapping(path = "/oneriMonParcheggi", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET, headers = "Accept=application/json")
//	public List<OnereMonetizzazioneParcheggio> selectOnMonParchList(
//            @ApiParam(value = "Jwt token", required=true) @RequestHeader(value = "Authorization",required=true) String jwtToken,                
//            @ApiParam(value = "Codice ente di lavoro", required = true) @RequestHeader(value = "COD_ENTE", required = true) String codEnte        ) {
//	
//		return oneriApiService.selectOnMonParchList(codEnte);
//		}
//	
}
