package it.eng.tributi.jente.ms.oneri.dto.api;

import java.io.Serializable;
import java.util.List;

import it.eng.tributi.jente.ms.oneri.dto.model.OnereUrbanizzazioneCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.OneriCostruzioneCalcolo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DatiOneriApi implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
//	protected String codEnte;
	protected Long idOnereCoefficiente;
	protected List<OnereUrbanizzazioneCalcolo> oneriUrbanizzazione;
	protected OneriCostruzioneCalcolo oneriCostr;
        protected String tipoPagamento;
        protected boolean daPagareSubito;

}
