package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import it.eng.tributi.jente.ms.oneri.dto.util.BigDecimalItalianDeserializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OnereUrbanizzazioneCalcolo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected String parametro2;
	protected String parametro1;
	protected Long idOneriDestinazioneUso;

	@JsonDeserialize(using=BigDecimalItalianDeserializer.class)
	protected BigDecimal volumeVuotoPerPieno;

}
