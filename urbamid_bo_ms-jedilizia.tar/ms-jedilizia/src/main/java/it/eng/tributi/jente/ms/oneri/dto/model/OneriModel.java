package it.eng.tributi.jente.ms.oneri.dto.model;

import it.eng.tributi.jente.ms.oneri.dto.model.OnereUrbanizzazione;
import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OneriModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected List<OnereUrbanizzazioneCalcolo> oneriUrbCalc;
	protected OneriCostruzioneCalcolo oneriCostrInf2000Calc;
	protected OneriCostruzioneCalcolo oneriCostrSup2000Calc;
	protected OneriParcheggiCalcolo oneriParchCalc;
	
	protected List<OnereResponse> totOneriUrb;
	protected OnereUrbanizzazione onereUrbanizzazione;
	protected OnereCostruzione onereCostruzione;

}
