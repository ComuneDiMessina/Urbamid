package it.eng.tributi.jente.ms.oneri.dto.model;

import it.eng.tributi.jente.ms.oneri.dto.api.OnereCostruzioneApi;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import it.eng.tributi.jente.ms.oneri.dto.db.OnereCostruzioneDB;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OnereCostruzione implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriCostruzione;
	protected BigDecimal costo;
	protected BigDecimal percentuale;
	protected BigDecimal detrazione;
	protected Date rowTsMod;
	
	public int hashKey() {
		final int prime = 31;
		int result = 0;
		result = prime * result + ((idOneriCostruzione == null) ? 0 : idOneriCostruzione.hashCode());
		return result;
	}
	
	public OnereCostruzioneDB getDBDTO() {
		return OnereCostruzioneDB.builder()
		.idOneriCostruzione(idOneriCostruzione)
		.costo(costo)
		.percentuale(percentuale)
		.detrazione(detrazione)
		.rowTsMod(rowTsMod)
		.build();
	}
	
	public static List<OnereCostruzioneApi> linkOnereCostruzioneApiFromModel(List<OnereCostruzione> items){
		 ArrayList<OnereCostruzioneApi> links = new ArrayList<>();
	        for (OnereCostruzione item : items) {
	        	OnereCostruzioneApi link = OnereCostruzioneApi.builder()
	        			.idOneriCostruzione(item.getIdOneriCostruzione())
	        			.costo(item.getCosto())
	        			.percentuale(item.getPercentuale())
	        			.detrazione(item.getDetrazione())
	        			.build();
	            links.add(link);
	        }
	        return links;
	}
}
