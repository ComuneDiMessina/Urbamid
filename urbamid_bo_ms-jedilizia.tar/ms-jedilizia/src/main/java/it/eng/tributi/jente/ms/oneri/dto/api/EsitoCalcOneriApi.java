package it.eng.tributi.jente.ms.oneri.dto.api;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EsitoCalcOneriApi implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Boolean esitoCalcolo;
	protected String messaggioEsito;

	protected BigDecimal oneriUrbPrimMax2000;
	protected BigDecimal oneriUrbPrimMax4000;
	protected BigDecimal oneriUrbPrimOltre4000;
	protected BigDecimal oneriUrbPrimTotali;
	protected BigDecimal oneriUrbSecMax2000;
	protected BigDecimal oneriUrbSecMax4000;
	protected BigDecimal oneriUrbSecOltre4000;
	protected BigDecimal oneriUrbSecTotali;
	protected BigDecimal oneriCostruzione;
	protected BigDecimal oneriCostrTotali;
	protected BigDecimal oneriParcheggi;
	protected BigDecimal oneriTotali;

}
