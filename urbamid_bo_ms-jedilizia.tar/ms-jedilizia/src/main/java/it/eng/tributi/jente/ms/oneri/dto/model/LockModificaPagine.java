package it.eng.tributi.jente.ms.oneri.dto.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class LockModificaPagine {

	protected Utente utente;
	protected String pagina;
	protected Long idOggetto;
	protected String tipoOggetto;
	protected Date tsInizioModifica;
}
