package it.eng.tributi.jente.ms.oneri.dto.db;

import it.eng.tributi.jente.ms.oneri.dto.db.DBOrmHistory;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=true)
@SuperBuilder
public class OnereParcheggioDB extends DBOrmHistory {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriParch;
	protected BigDecimal mqSulIncr;
	protected BigDecimal mqParchRep;
	protected BigDecimal costo;
	
}
