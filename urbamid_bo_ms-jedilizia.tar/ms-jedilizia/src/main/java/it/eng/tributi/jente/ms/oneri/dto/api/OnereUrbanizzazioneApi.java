package it.eng.tributi.jente.ms.oneri.dto.api;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OnereUrbanizzazioneApi implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriUrbaniz;
	protected String unitaMisura;
	protected BigDecimal quantita;
	protected BigDecimal tributo1;
	protected BigDecimal detrazione1;
	protected BigDecimal tributo2;
	protected BigDecimal detrazione2;
	protected Date rowTsMod;
	
}
