package it.eng.tributi.jente.ms.oneri.dto.model;

import it.eng.tributi.jente.ms.oneri.dto.model.OneriParcheggiCalcolo;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProcedimentoOnereParchSul implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriParchSul;
	protected Long idProcedimento;
	protected BigDecimal mqSulIncr;
	protected BigDecimal mqParchRep;
	
	public static List<OneriParcheggiCalcolo> linkOnereParcheggioCalcFromModel(List<ProcedimentoOnereParchSul> items){
		 ArrayList<OneriParcheggiCalcolo> links = new ArrayList<>();
	        for (ProcedimentoOnereParchSul item : items) {
	        	OneriParcheggiCalcolo link = OneriParcheggiCalcolo.builder()
	        			.sulIncremento(item.getMqSulIncr())
	        			.mqParchRep(item.getMqParchRep())
	        			.build();
	            links.add(link);
	        }
	        return links;
	}
}
