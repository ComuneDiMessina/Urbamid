package it.eng.tributi.jente.ms.oneri.dto.api;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UtenteApi implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Boolean assegna;
	protected Boolean attivo;
	protected String cognome;
	protected Date dataFine;
	protected Date dataInizio;
	protected String email;
	protected String matricola;
	protected String nome;
	protected String password;
	protected SezioneApi sezione;
	protected Long idEnte;
	
}
