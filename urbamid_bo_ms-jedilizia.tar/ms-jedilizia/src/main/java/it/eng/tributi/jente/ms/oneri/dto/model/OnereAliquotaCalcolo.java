package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class OnereAliquotaCalcolo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected String codiceClasse;
	protected String codiceTipologia;
 	protected String codiceDestinazione;       
}
