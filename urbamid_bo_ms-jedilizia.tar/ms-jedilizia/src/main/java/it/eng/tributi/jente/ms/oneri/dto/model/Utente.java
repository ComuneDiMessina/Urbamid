package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import it.eng.tributi.jente.ms.oneri.dto.api.UtenteApi;
import it.eng.tributi.jente.ms.oneri.util.SSOUser;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Utente implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Boolean assegna;
	protected Boolean attivo;
	protected String cognome;
	protected Date dataFine;
	protected Date dataInizio;
	protected String email;
	protected Long idUtente;
	protected String matricola;
	protected String nome;
	protected String password;
	protected Long idEnte;
	protected Ente ente;
	protected List<Responsabile> mansioni;
	protected SSOUser userInfo;
	protected List<Ruolo> listaRuoli;
	protected String commentoAssegnazione;
	protected Boolean flagFirmaDigitale;
	protected String qualifica;
	protected String usernameAruba;
	
	
	
	public String getNominativo() {
		return (null==cognome ? "" : cognome.trim()+" ") + (null==nome ? "" : nome.trim());
	}
	
	public String getUtenteSezione() {
		return getNominativo() 
				+ (null!=getMansionePrincipale() && null != getMansionePrincipale().getSezione() && null!=getMansionePrincipale().getSezione().getNome() ? " ["+getMansionePrincipale().getSezione().getNome()+"]" : "");
	}
	
	public Responsabile getMansionePrincipale() {
		if(null == mansioni)
			return null;
		for(Responsabile resp: mansioni) {
			if(resp.getFlagPrincipale() != null && resp.getFlagPrincipale()) {
				return resp;
			}
		}
		return null;
	}
	
	public static UtenteApi linkUtenteApiFromModel(Utente utente){
		UtenteApi link = UtenteApi.builder()
				.assegna(utente.getAssegna())
				.attivo(utente.getAttivo())
				.cognome(utente.getCognome())
				.dataFine(utente.getDataFine())
				.dataInizio(utente.getDataInizio())
				.email(utente.getEmail())
				.matricola(utente.getMatricola())
				.nome(utente.getNome())
				.password(utente.getPassword())
				.idEnte(utente.getIdEnte())
				.build();
		return link;
	}
	
	public Set<String> getFunzioniUtente(){
		Set<String> codiciFunzioni = new HashSet<>();
		for (Ruolo ruolo : listaRuoli) {
			for (Funzione funz : ruolo.getListaFunzioni())
				codiciFunzioni.add(funz.getCodFunzione());
		}
		return codiciFunzioni;
	}
}
