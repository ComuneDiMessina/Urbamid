package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OnereIncrementoServizio implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idIncrementoServ;
	protected BigDecimal minIntervallo;
	protected BigDecimal maxIntervallo;
	protected BigDecimal percIncremento;
	protected Boolean attivo;
	
}
