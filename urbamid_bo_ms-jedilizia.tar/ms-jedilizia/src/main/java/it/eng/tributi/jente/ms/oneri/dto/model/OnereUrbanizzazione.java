package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import it.eng.tributi.jente.ms.oneri.dto.api.OnereUrbanizzazioneApi;
import it.eng.tributi.jente.ms.oneri.dto.db.OnereUrbanizzazioneDB;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OnereUrbanizzazione implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriUrbaniz;
	protected String unitaMisura;
	protected BigDecimal quantita;
	protected BigDecimal tributo1;
	protected BigDecimal detrazione1;
	protected BigDecimal tributo2;
	protected BigDecimal detrazione2;
	protected Date rowTsMod;
	
	public int hashKey() {
		final int prime = 31;
		int result = 0;
		result = prime * result + ((idOneriUrbaniz == null) ? 0 : idOneriUrbaniz.hashCode());
		return result;
	}
	
	public OnereUrbanizzazioneDB getDBDTO() {
		return OnereUrbanizzazioneDB.builder()
		.idOneriUrbaniz(idOneriUrbaniz)
		.unitaMisura(unitaMisura)
		.quantita(quantita)
		.tributo1(tributo1)	
		.detrazione1(detrazione1)
		.tributo2(tributo2)
		.detrazione2(detrazione2)
		.rowTsMod(rowTsMod)
		.build();
	}

	public static List<OnereUrbanizzazioneApi> linkOnereUrbanizzazioneeApiFromModel(List<OnereUrbanizzazione> items){
		 ArrayList<OnereUrbanizzazioneApi> links = new ArrayList<>();
	        for (OnereUrbanizzazione item : items) {
	        	OnereUrbanizzazioneApi link = OnereUrbanizzazioneApi.builder()
	        			.idOneriUrbaniz(item.getIdOneriUrbaniz())
	        			.unitaMisura(item.getUnitaMisura())
	        			.quantita(item.getQuantita())
	        			.tributo1(item.getTributo1())
	        			.detrazione1(item.getDetrazione1())
	        			.tributo2(item.getTributo2())
	        			.detrazione2(item.getDetrazione2())
	        			.build();
	            links.add(link);
	        }
	        return links;
	}
}
