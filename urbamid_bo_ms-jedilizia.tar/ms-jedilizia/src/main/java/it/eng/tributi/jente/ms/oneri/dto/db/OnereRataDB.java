package it.eng.tributi.jente.ms.oneri.dto.db;

import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=true)
@SuperBuilder
public class OnereRataDB extends DBOrmHistory {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriRata;
	protected Long tipoOneriRata;
	protected Long rata;
	protected Date dataScadenza;
	protected BigDecimal importo;
	protected BigDecimal pagato;
	protected BigDecimal impSanzione;
	protected Date dataPagamento;
	protected Date dataPagSanzione;
		
}
