/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.eng.tributi.jente.ms.oneri.util;

import it.eng.tributi.jente.ms.commons.util.exception.GenericException;
import it.eng.tributi.jente.ms.oneri.dao.impl.OneriDAO;
import it.eng.tributi.jente.ms.oneri.dto.api.DatiOneriApi;
import it.eng.tributi.jente.ms.oneri.dto.model.CoefficienteMaggiorazioneCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.CostoCostruzioneAbbattutoCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.DettaglioSuperficiAccessorie;
import it.eng.tributi.jente.ms.oneri.dto.model.DettaglioSuperficiTuristicheCommerciali;
import it.eng.tributi.jente.ms.oneri.dto.model.Esito;
import it.eng.tributi.jente.ms.oneri.dto.model.IncrementoCaratteristica;
import it.eng.tributi.jente.ms.oneri.dto.model.IncrementoClasse;
import it.eng.tributi.jente.ms.oneri.dto.model.InputList;
import it.eng.tributi.jente.ms.oneri.dto.model.Item;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereAliquotaCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereCoefficiente;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereIncremento;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereUrbanizzazioneCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.OneriCostruzioneCalcolo;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConverterMapInObject {

    private OneriDAO oneriDAO;
    
    private static Logger logger = LoggerFactory.getLogger(ConverterMapInObject.class);
    protected HashMap<String, String> map;
    protected String codEnte;
    HashMap<String, String> errorMap;

    public ConverterMapInObject(HashMap<String, String> map, String codEnte,OneriDAO oneriDAO) {
        this.map = map;
        this.codEnte = codEnte;
        this.oneriDAO=oneriDAO;
        errorMap=Utils.getErrorMap();
    }

    public ConverterMapInObject(InputList inputList, String codEnte,OneriDAO oneriDAO) {
        this.map = getMap(inputList);
        this.codEnte = codEnte;
        this.oneriDAO=oneriDAO;   
        errorMap=Utils.getErrorMap();        
    }

    public static HashMap<String, String> getMap(InputList inputList) {
        HashMap<String, String> result = new HashMap();
        for (Item item : inputList.getList()) {
            if (item.getKey() != null) {
                result.put(item.getKey(), Utils.vbTrim(item.getValue()));
            }
        }
        return result;
    }
    
    public static InputList getInputList(HashMap<String,String> map) {
        InputList result = new InputList();
        List<Item> list=new ArrayList();
        Set set=map.entrySet();
        Iterator i = set.iterator();
        
        while(i.hasNext()){
            Item item=new Item();
            Map.Entry mapEntry = (Map.Entry) i.next();
            item.setKey((String) mapEntry.getKey());
            item.setValue((String) mapEntry.getValue());
            list.add(item);
        }
        result.setList(list);
        return result;
    }
    
    public  HashMap<String, String>  getInputMap(){
        return map;
    }

    private IncrementoClasse getIncrementoClasse(int progressivo) throws Exception {
        IncrementoClasse result = new IncrementoClasse();
        result.setIdClasseSul(DizionarioConstant.ONERI_COSTR_CLASSI);
        String codIncremento = ("00" + progressivo + "").substring((progressivo + "").length());
        result.setCodIncremento(codIncremento);

        int numAlloggi;

        try {
            numAlloggi = map.containsKey(DizionarioConstant.LABEL_NUMERO_ALLOGGI_SU_PREFIX + progressivo)
                    ? Integer.parseInt(map.get(DizionarioConstant.LABEL_NUMERO_ALLOGGI_SU_PREFIX + progressivo)) : 0;
        } catch (NumberFormatException e) {
            String errore = "Valore '" + errorMap.get(DizionarioConstant.LABEL_NUMERO_ALLOGGI_SU_PREFIX + progressivo) + "' non numerico: " + map.get(DizionarioConstant.LABEL_NUMERO_ALLOGGI_SU_PREFIX + progressivo);
            logger.error(errore);
            throw new Exception(errore);
        }
        result.setNumAlloggi(numAlloggi);

        BigDecimal sulAlloggi = null;
        try {
            sulAlloggi = new BigDecimal(map.containsKey(DizionarioConstant.LABEL_NUMERO_SU_PER_CLASSE_PREFIX + progressivo)
                    ? map.get(DizionarioConstant.LABEL_NUMERO_SU_PER_CLASSE_PREFIX + progressivo) : "0").setScale(2, RoundingMode.HALF_DOWN);
        } catch (NumberFormatException e) {
            String errore= "Valore '"+errorMap.get(DizionarioConstant.LABEL_NUMERO_SU_PER_CLASSE_PREFIX + progressivo)+"' non numerico: "+map.get(DizionarioConstant.LABEL_NUMERO_SU_PER_CLASSE_PREFIX + progressivo);
            logger.error(errore);
            throw new Exception(errore);
        }
        result.setSulAlloggi(sulAlloggi.setScale(2));

        return result;

    }

    private List<IncrementoClasse> getIncrementiClassi() throws Exception {
        List<IncrementoClasse> result = new ArrayList();

        List<OnereIncremento> list = oneriDAO.selectOnereIncrListByCl(DizionarioConstant.ONERI_COSTR_CLASSI);
        int size = 0;
        if (list != null) {
            size = list.size();
            for (int i = 1; i <= size; i++) {
                result.add(getIncrementoClasse(i));
            }
        } else {
            logger.error("Non sono stati impostati incrementi classe (OI01 - tabella ONERI_INCREMENTALI)");
            throw new Exception("Non sono stati impostati incrementi classe");
        }
        
        return result;
    }

    private DettaglioSuperficiAccessorie getDettaglioSupAccessorie() throws Exception {
        DettaglioSuperficiAccessorie result = new DettaglioSuperficiAccessorie();

         BigDecimal sulAndroni = null;
        try {
            sulAndroni = new BigDecimal(map.containsKey(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_ANDRONI)
                    ? map.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_ANDRONI ) : "0").setScale(2, RoundingMode.HALF_DOWN);
        } catch (NumberFormatException e) {
            String errore= "Valore '"+errorMap.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_ANDRONI)+"' non numerico: "+map.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_ANDRONI);
            logger.error(errore);
            throw new Exception(errore);
        }         

        result.setSulAndroni(sulAndroni);
        
        
        
         BigDecimal sulAutorimesse = null;
        try {
            sulAutorimesse = new BigDecimal(map.containsKey(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_AUTORIMESSE_SINGOLE)
                    ? map.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_AUTORIMESSE_SINGOLE ) : "0").setScale(2, RoundingMode.HALF_DOWN);
        } catch (NumberFormatException e) {
            String errore= "Valore '"+errorMap.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_AUTORIMESSE_SINGOLE)+"' non numerico: "+map.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_AUTORIMESSE_SINGOLE);
            logger.error(errore);
            throw new Exception(errore);
        }      
        
        result.setSulAutorimesse(sulAutorimesse);
        
        
        BigDecimal sulAutorimesseCollettive = null;
        try {
            sulAutorimesseCollettive = new BigDecimal(map.containsKey(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_AUTORIMESSE_COLLETTIVE)
                    ? map.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_AUTORIMESSE_COLLETTIVE ) : "0").setScale(2, RoundingMode.HALF_DOWN);
        } catch (NumberFormatException e) {
            String errore= "Valore '"+errorMap.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_AUTORIMESSE_COLLETTIVE)+"' non numerico: "+map.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_AUTORIMESSE_COLLETTIVE);
            logger.error(errore);
            throw new Exception(errore);
        }             

        result.setSulAutorimesseCollettive(sulAutorimesseCollettive);

        
        BigDecimal sulBalconi = null;
        try {
            sulBalconi = new BigDecimal(map.containsKey(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_BALCONI)
                    ? map.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_BALCONI ) : "0").setScale(2, RoundingMode.HALF_DOWN);
        } catch (NumberFormatException e) {
            String errore= "Valore '"+errorMap.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_BALCONI)+"' non numerico: "+map.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_BALCONI);
            logger.error(errore);
            throw new Exception(errore);
        }  

        result.setSulBalconi(sulBalconi);

         BigDecimal sulCantine = null;
        try {
            sulCantine = new BigDecimal(map.containsKey(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_CANTINE)
                    ? map.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_CANTINE ) : "0").setScale(2, RoundingMode.HALF_DOWN);
        } catch (NumberFormatException e) {
            String errore= "Valore '"+errorMap.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_CANTINE)+"' non numerico: "+map.get(DizionarioConstant.LABEL_SUPERFICI_ACCESSORIE_CANTINE);
            logger.error(errore);
            throw new Exception(errore);
        }         

        result.setSulCantine(sulCantine);

        return result;

    }

    private DettaglioSuperficiTuristicheCommerciali getDettaglioSupTuristicheCommerciali() throws Exception {
        DettaglioSuperficiTuristicheCommerciali result = new DettaglioSuperficiTuristicheCommerciali();

        BigDecimal sulNettaNonResidenziale = null;
        try {
            sulNettaNonResidenziale = new BigDecimal(map.containsKey(DizionarioConstant.LABEL_SUPERFICIE_NETTA_NON_RESIDENZIALE)
                    ? map.get(DizionarioConstant.LABEL_SUPERFICIE_NETTA_NON_RESIDENZIALE ) : "0").setScale(2, RoundingMode.HALF_DOWN);
        } catch (NumberFormatException e) {
            String errore= "Valore '"+errorMap.get(DizionarioConstant.LABEL_SUPERFICIE_NETTA_NON_RESIDENZIALE)+"' non numerico: "+map.get(DizionarioConstant.LABEL_SUPERFICIE_NETTA_NON_RESIDENZIALE);
            logger.error(errore);
            throw new Exception(errore);
        }            

        result.setSulNettaNonResidenziale(sulNettaNonResidenziale);
        
        
       BigDecimal sulAccessori = null;
       try {
            sulAccessori = new BigDecimal(map.containsKey(DizionarioConstant.LABEL_SUPERFICIE_ACCESSORI_NON_RESIDENZIALE)
                    ? map.get(DizionarioConstant.LABEL_SUPERFICIE_ACCESSORI_NON_RESIDENZIALE ) : "0").setScale(2, RoundingMode.HALF_DOWN);
        } catch (NumberFormatException e) {
            String errore= "Valore '"+errorMap.get(DizionarioConstant.LABEL_SUPERFICIE_ACCESSORI_NON_RESIDENZIALE)+"' non numerico: "+map.get(DizionarioConstant.LABEL_SUPERFICIE_ACCESSORI_NON_RESIDENZIALE);
            logger.error(errore);
            throw new Exception(errore);
        }           

        result.setSulAccessori(sulAccessori);

        return result;

    }

    private IncrementoCaratteristica getIncrementoCaratteristico(int progressivo) throws Exception {
        IncrementoCaratteristica result;
        if (map.containsKey(DizionarioConstant.LABEL_CARATTERISTICA_PARTICOLARE_PREFIX + progressivo)
                && map.get(DizionarioConstant.LABEL_CARATTERISTICA_PARTICOLARE_PREFIX + progressivo).equals("S")) {
            result = new IncrementoCaratteristica();
            result.setClasseIncremento(DizionarioConstant.ONERI_COSTR_CAR);
            String codIncremento = ("00" + progressivo + "").substring((progressivo + "").length());

            result.setCodIncremento(codIncremento);
        } else {
            result = null;
        }
        return result;

    }

    private List<IncrementoCaratteristica> getIncrementiCaratteristici() throws Exception {
        List<IncrementoCaratteristica> result = new ArrayList();
        
        List<OnereIncremento>  list = oneriDAO.selectOnereIncrListByCl(DizionarioConstant.ONERI_COSTR_CAR);

        int size = 0;
        if (list != null) {
            size = list.size();
            for (int i = 1; i <= size; i++) {
                IncrementoCaratteristica incrementoCaratteristica = getIncrementoCaratteristico(i);
                if (incrementoCaratteristica != null) {
                    result.add(incrementoCaratteristica);
                }
            }
        } else {
            logger.error("Non sono stati impostati incrementi caratteristici (OI02 - tabella ONERI_INCREMENTALI)");
            throw new Exception("Non sono stati impostati incrementi caratteristici");
        }

        return result;
    }

    private CoefficienteMaggiorazioneCalcolo getCoefficienteMaggiorazioneCalcolo() throws Exception {
        CoefficienteMaggiorazioneCalcolo coefficienteMaggiorazioneCalcolo = new CoefficienteMaggiorazioneCalcolo();
        coefficienteMaggiorazioneCalcolo.setIncrementiClassi(getIncrementiClassi());
        coefficienteMaggiorazioneCalcolo.setIncrementiCaratt(getIncrementiCaratteristici());
        coefficienteMaggiorazioneCalcolo.setDettaglioSuperficiAccessorie(getDettaglioSupAccessorie());
        coefficienteMaggiorazioneCalcolo.setDettaglioSuperficiTuristicheCommerciali(getDettaglioSupTuristicheCommerciali());
        return coefficienteMaggiorazioneCalcolo;
    }

    private CostoCostruzioneAbbattutoCalcolo getCostoCostruzioneAbbattutoCalcolo() throws Exception {
        CostoCostruzioneAbbattutoCalcolo result = new CostoCostruzioneAbbattutoCalcolo();
        result.setIdDestinazioneCC(new Long(1));
        OnereAliquotaCalcolo onereAliquotaCalcolo = new OnereAliquotaCalcolo();
        onereAliquotaCalcolo.setCodiceDestinazione(Utils.vbTrim(map.get(DizionarioConstant.LABEL_CODICE_DESTINAZIONE)));
        onereAliquotaCalcolo.setCodiceTipologia(Utils.vbTrim(map.get(DizionarioConstant.LABEL_CODICE_TIPOLOGIA)));
        result.setOnereAliquotaCalcolo(onereAliquotaCalcolo);
        return result;
    }

    private OneriCostruzioneCalcolo getOneriCostruzioneCalcolo() throws Exception {
        OneriCostruzioneCalcolo oneriCostruzione = new OneriCostruzioneCalcolo();
        oneriCostruzione.setCoefficienteMaggiorazioneCalcolo(getCoefficienteMaggiorazioneCalcolo());
        oneriCostruzione.setCostoCostruzioneAbbattutoCalcolo(getCostoCostruzioneAbbattutoCalcolo());
        return oneriCostruzione;
    }

    private List<OnereUrbanizzazioneCalcolo> getOneriUrbanizzazioneCalcolo() throws Exception {
        List<OnereUrbanizzazioneCalcolo> result = new ArrayList();
        OnereUrbanizzazioneCalcolo onereUrbanizzazioneCalcolo = new OnereUrbanizzazioneCalcolo();
        result.add(onereUrbanizzazioneCalcolo);

        onereUrbanizzazioneCalcolo.setIdOneriDestinazioneUso(new Long(1));
        if (map.containsKey(DizionarioConstant.LABEL_ONERI_URB_PARAMETRO1)) {
            onereUrbanizzazioneCalcolo.setParametro1(map.get(DizionarioConstant.LABEL_ONERI_URB_PARAMETRO1));
        } else {
            logger.error("Oneri Urbanizzazione, scegliere Zona PRG");
            throw new Exception("Oneri Urbanizzazione, scegliere Zona PRG");
        }

        if (map.containsKey(DizionarioConstant.LABEL_ONERI_URB_PARAMETRO2)) {
            onereUrbanizzazioneCalcolo.setParametro2(map.get(DizionarioConstant.LABEL_ONERI_URB_PARAMETRO2));
        } else {
            logger.error("Oneri Urbanizzazione, scegliere Zona");
            throw new Exception("Oneri Urbanizzazione, scegliere Zona");
        }

        if (map.containsKey(DizionarioConstant.LABEL_ONERI_URB_VPP)) {
            
            BigDecimal vvp = null;
            try {
                vvp = new BigDecimal(map.containsKey(DizionarioConstant.LABEL_ONERI_URB_VPP)
                        ? map.get(DizionarioConstant.LABEL_ONERI_URB_VPP) : "0").setScale(2, RoundingMode.HALF_DOWN);
            } catch (NumberFormatException e) {
                String errore = "Valore '" + errorMap.get(DizionarioConstant.LABEL_ONERI_URB_VPP) + "' non numerico: " + map.get(DizionarioConstant.LABEL_ONERI_URB_VPP);
                logger.error(errore);
                throw new Exception(errore);
            }    
            
            onereUrbanizzazioneCalcolo.setVolumeVuotoPerPieno(vvp);
        } else {
            logger.error("Oneri Urbanizzazione, immettere valore volume vuoto per pieno");
            throw new Exception("Oneri Urbanizzazione, immettere valore volume vuoto per pieno");
        }
        return result;
    }

    private Long getIdOnereCoefficiente() {
        return new Long(1);
    }
    
    private boolean getDaPagareSubito() throws Exception{
        if (map.containsKey(DizionarioConstant.LABEL_TIPO_DOMANDA)) {
            OnereCoefficiente destinazioneObject = oneriDAO.selectOnereCoeffByCod(map.get(DizionarioConstant.LABEL_TIPO_DOMANDA), DizionarioConstant.ONERI_CLASS_TIPO_DOMANDA);
            if (null == destinazioneObject) {
                throw new Exception("Tipo Domanda - Onere coefficiente  non presente in DB (" + map.get(DizionarioConstant.LABEL_TIPO_DOMANDA) + ")");
            }
            return destinazioneObject.getValore().compareTo(new BigDecimal(0)) > 0;

        } else {
            logger.error("Tipo Domanda obbligatorio, scegliere tipo di domanda che sarà presentata");
            throw new Exception("Tipo Domanda obbligatorio, scegliere tipo di domanda che sarà presentata");
        }
    }

    private String getTipoPagamento() throws Exception {
        String result;
        if (map.containsKey(DizionarioConstant.LABEL_TIPO_PAGAMENTO)) {
            String tipo = map.get(DizionarioConstant.LABEL_TIPO_PAGAMENTO);
            if (tipo.equalsIgnoreCase(DizionarioConstant.TIPO_PAGAMENTO_UNICA)
                    || tipo.equalsIgnoreCase(DizionarioConstant.TIPO_PAGAMENTO_RATE)
                    || tipo.equalsIgnoreCase(DizionarioConstant.TIPO_PAGAMENTO_PREMIALITA)) {
                result = tipo.toUpperCase();

            } else {
                logger.error("Tipo Pagamento obbligatorio, scegliere se pagamento è UNICA SOLUZIONE - RATE - PREMIALITA'");
                throw new Exception("Tipo Pagamento obbligatorio, scegliere se pagamento è UNICA SOLUZIONE - RATE - PREMIALITA'");
            }
        } else {
            logger.error("Tipo Pagamento obbligatorio, scegliere se pagamento è UNICA SOLUZIONE - RATE - PREMIALITA'");
            throw new Exception("Tipo Pagamento obbligatorio, scegliere se pagamento è UNICA SOLUZIONE - RATE - PREMIALITA'");
        }
        return result;
    }
    
    public Esito ctrlInputList() throws Exception{
        String[] obbligatori=(DizionarioConstant.CTRL_OBBLIGATORI).split(";");
        String errore="";
        Esito esito=new Esito();
        esito.setOk(true);
        if(obbligatori!=null && obbligatori.length>0){
            for(String item:obbligatori){
                String[] value=item.split("#");
                if(!map.containsKey(value[0])){
                    errore=errore+value[1]+";";
                }
            }
        }
        if(!errore.equals("")){
            esito.setOk(false);
            esito.setMessaggio("Compilare i seguenti campi:"+errore);
        }
        return esito;
    }

    public DatiOneriApi getDatiOneriApi() throws Exception {
        DatiOneriApi result = new DatiOneriApi();
        result.setIdOnereCoefficiente(getIdOnereCoefficiente());
        result.setDaPagareSubito(getDaPagareSubito());
        result.setOneriCostr(getOneriCostruzioneCalcolo());
        result.setOneriUrbanizzazione(getOneriUrbanizzazioneCalcolo());
        result.setTipoPagamento(getTipoPagamento());
        return result;
    }
}
