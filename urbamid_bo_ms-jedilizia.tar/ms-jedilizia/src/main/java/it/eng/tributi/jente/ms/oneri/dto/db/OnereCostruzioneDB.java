package it.eng.tributi.jente.ms.oneri.dto.db;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=true)
@SuperBuilder
public class OnereCostruzioneDB extends DBOrmHistory {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriCostruzione;
	protected BigDecimal costo;
	protected BigDecimal percentuale;
	protected BigDecimal detrazione;
	
}
