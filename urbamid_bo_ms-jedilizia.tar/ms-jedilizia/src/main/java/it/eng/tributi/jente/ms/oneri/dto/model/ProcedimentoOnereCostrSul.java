package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProcedimentoOnereCostrSul implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idOneriCostrSul;
	protected Long idProcedimento;
	protected Boolean flagIntSup2000;
	protected Boolean flagEnergiaSolare;
	protected Boolean flagStrutturaPortante;
	protected Boolean flagBioedilizia;
	protected BigDecimal sulCantine;
	protected BigDecimal sulAutorimesse;
	protected BigDecimal sulAndroni;
	protected BigDecimal sulBalconi;
	protected BigDecimal sulAbitabile;
	protected BigDecimal sulNonResid;
	protected BigDecimal sulComm;
	protected BigDecimal sulAccessComm;
	protected BigDecimal sulTurist;
	protected BigDecimal sulAccessTurist;
	protected List<ProcedimentoOnereCoeffSul> oneriCoeffSul;
	protected List<ProcedimentoOnereIncremSul> oneriIncrSul;
	
}
