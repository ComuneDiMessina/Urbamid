package it.eng.tributi.jente.ms.oneri.service.api.impl;

import it.arezzo.infor.jente.jutility.UtilString;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.eng.tributi.jente.ms.oneri.dto.api.DatiOneriApi;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereCoefficiente;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereIncremento;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereResponse;
import it.eng.tributi.jente.ms.oneri.dao.impl.OneriDAO;
import it.eng.tributi.jente.ms.oneri.dto.model.Esito;
import it.eng.tributi.jente.ms.oneri.dto.model.InputList;
import it.eng.tributi.jente.ms.oneri.dto.model.MultipleChoice;
import it.eng.tributi.jente.ms.oneri.dto.model.SingleChoice;
import it.eng.tributi.jente.ms.oneri.dto.model.SingleChoiceList;
import it.eng.tributi.jente.ms.oneri.service.OneriService;
import it.eng.tributi.jente.ms.oneri.service.api.OneriApiService;
import it.eng.tributi.jente.ms.oneri.service.impl.AbstractServiceImpl;
import it.eng.tributi.jente.ms.oneri.util.ConverterMapInObject;
import it.eng.tributi.jente.ms.oneri.util.DizionarioConstant;
import it.eng.tributi.jente.ms.oneri.util.Utils;
import java.util.ArrayList;
import java.util.HashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Service
public class OneriApiServiceImpl  extends AbstractServiceImpl implements  OneriApiService {
	
	@Autowired
	private OneriService oneriService;

	@Autowired
	private OneriDAO oneriDAO;
	
        private static Logger logger = LoggerFactory.getLogger(OneriApiServiceImpl.class);

        
 	@Override
	public OnereResponse publicCalcolaOneriApi(InputList inputList, String codiceEnte) {
            return calcolaOneriApi(ANONIMOUS.getCodFiscale(),inputList,codiceEnte);
        }   
        
	@Override
	public OnereResponse calcolaOneriApi(String codiceFiscale,InputList inputList, String codiceEnte) {
            return calcolaOneriApi(codiceFiscale,inputList,codiceEnte, false);  
        }
        
 	@Override       
	public OnereResponse publicCalcolaOneriApiBO(InputList inputList, String codiceEnte) {
            return calcolaOneriApi(ANONIMOUS.getCodFiscale(),inputList,codiceEnte, true);  
        }
       

	private OnereResponse calcolaOneriApi(String codiceFiscale,InputList inputList, String codiceEnte, boolean operatoreBO) {
            OnereResponse result = new OnereResponse();  
            
            try {
                ConverterMapInObject converterUtil =new ConverterMapInObject( inputList,  codiceEnte,oneriDAO);
                Esito esitoCtrl=converterUtil.ctrlInputList();
                if (esitoCtrl.isOk()) {
                    DatiOneriApi datiOneri = converterUtil.getDatiOneriApi();

                    HashMap<String, String> oneriMap = converterUtil.getInputMap();
//		Long codEnte = adminDAO.getIdEnte(datiOneri.getCodEnte());

                    boolean daPagareSubito=true; // se è operatore BO allora è da pagare subito ancghe se PdC
                    if(!operatoreBO) {
                        daPagareSubito=datiOneri.isDaPagareSubito();
                    }
                    
                    result = oneriService.calcOneriUrbanizzazione(datiOneri.getOneriUrbanizzazione(), oneriMap, codiceEnte,datiOneri.getTipoPagamento(), daPagareSubito);
                    if (result.getEsito().isOk()) {
                        result = oneriService.calcOneriCostruzione(datiOneri.getOneriCostr(), oneriMap, codiceEnte,datiOneri.getTipoPagamento(), daPagareSubito);
                        if (result.getEsito().isOk()) {
                            result.setOutputList(ConverterMapInObject.getInputList(oneriMap));
                            boolean rate =Utils.daRateizzare(datiOneri.getTipoPagamento(), daPagareSubito);
                            result.setFilePdf(oneriService.getFilePdf(codiceFiscale, codiceEnte, oneriMap,rate));
                        }
                    }
                }
                else{
                    result.setEsito(esitoCtrl);
                }
                
            } catch (Exception ex) {
                logger.error(ex.getMessage());
                Esito esito = new Esito();
                Esito.creaMessaggioKO(esito, ex.getMessage());
                result.setEsito(esito);
            }
            return result;
	}
        
        @Override
        public List<MultipleChoice> selectClassiSuperficieList(String codEnte) {
            return selectMultipleChoiceListByOnereIncr( codEnte,DizionarioConstant.ONERI_COSTR_CLASSI,DizionarioConstant.LABEL_NUMERO_ALLOGGI_SU_PREFIX,DizionarioConstant.LABEL_NUMERO_SU_PER_CLASSE_PREFIX);

        }
        
        @Override
        public List<MultipleChoice> selectSuperficiResidenziali(String codEnte) {
            return selectMultipleChoiceListByOnereCoeff( codEnte,DizionarioConstant.ONERI_CLASS_SUPERFICI_RESIDENZIALI,DizionarioConstant.LABEL_SUPERFICI_RESIDENZIALI_PREFIX,null);

        }     
        
        @Override
        public List<MultipleChoice> selectCaratteristicheParticolari(String codEnte) {
            return selectMultipleChoiceListByOnereCoeff( codEnte,DizionarioConstant.ONERI_CLASS_CARATT_PARTICOLARI,DizionarioConstant.LABEL_CARATTERISTICA_PARTICOLARE_PREFIX,null);

        }    
        
        @Override
        public SingleChoiceList selectTipologiaEdificio(String codEnte) {
            return selectSingleChoiceListByOnereCoeff( codEnte,DizionarioConstant.ONERI_CLASS_TIPOLOGIA, DizionarioConstant.LABEL_CODICE_TIPOLOGIA);

        }     
        
        @Override
        public SingleChoiceList selectDestinazione(String codEnte) {
            return selectSingleChoiceListByOnereCoeff( codEnte,DizionarioConstant.ONERI_CLASS_DESTINAZIONE, DizionarioConstant.LABEL_CODICE_DESTINAZIONE);

        }      
        
         @Override
        public SingleChoiceList selectZona(String codEnte) {
            return selectSingleChoiceListByOnereCoeff( codEnte,DizionarioConstant.ONERI_FATTORI_CALCOLO_PARAM2, DizionarioConstant.LABEL_ONERI_URB_PARAMETRO2);

        }  
        
        @Override
        public SingleChoiceList selectZonaPRG(String codEnte) {
            return selectSingleChoiceListByOnereCoeff( codEnte,DizionarioConstant.ONERI_FATTORI_CALCOLO_PARAM1, DizionarioConstant.LABEL_ONERI_URB_PARAMETRO1);

        }       
        
        @Override
        public SingleChoiceList selectTipoDomanda(String codEnte) {
            return selectSingleChoiceListByOnereCoeff( codEnte,DizionarioConstant.ONERI_CLASS_TIPO_DOMANDA, DizionarioConstant.LABEL_TIPO_DOMANDA);

        }     
        
        @Override
        public SingleChoiceList selectTipoPagamento(String codEnte) {
            return selectSingleChoiceListByOnereCoeff( codEnte,DizionarioConstant.ONERI_CLASS_TIPO_PAGAMENTO, DizionarioConstant.LABEL_TIPO_PAGAMENTO);

        }               
        
        public List<MultipleChoice> selectMultipleChoiceListByOnereIncr(String codEnte,String codiceClasse,String label1,String label2) {
            List<MultipleChoice> result=new ArrayList();;
            List<OnereIncremento> onereIncrementoList=selectOnereIncrListByCl( codEnte, codiceClasse);
            for(OnereIncremento item:onereIncrementoList){
                String progressivo=UtilString.togliZeriSx(item.getCodIncremento());
                String labelx1=label1;
                String labelx2=label2;
               
                 if(label1!=null){
                    labelx1=label1+progressivo;
                }
                if(label2!=null){
                    labelx2=label2+progressivo;
                }                       
                result.add(MultipleChoice.getMultipleChoice(item, labelx1, labelx2));
            }
            return result;
        }     
          
        public SingleChoiceList selectSingleChoiceListByOnereCoeff(String codEnte,String codiceClasse, String label) {
            SingleChoiceList result=new SingleChoiceList();
            List<SingleChoice> list=new ArrayList();
            result.setSingleChoiceList(list);
            result.setLabel(label);
            List<OnereCoefficiente> onereCoefficienteList=selectOnereCoeffListByClasse( codEnte, codiceClasse);
            for(OnereCoefficiente item:onereCoefficienteList){           
                list.add(SingleChoice.getSingleChoice(item));
            }
            return result;
        }    
        
         public List<MultipleChoice> selectMultipleChoiceListByOnereCoeff(String codEnte,String codiceClasse, String label1,String label2) {
            List<MultipleChoice> result=new ArrayList();;
            List<OnereCoefficiente> onereCoefficienteList=selectOnereCoeffListByClasse( codEnte, codiceClasse);
            for(OnereCoefficiente item:onereCoefficienteList){
                String progressivo=UtilString.togliZeriSx(item.getCodCoefficiente());
                String labelx1=label1;
                String labelx2=label2;
               
                 if(label1!=null){
                    labelx1=label1+progressivo;
                }
                if(label2!=null){
                    labelx2=label2+progressivo;
                }               
                result.add(MultipleChoice.getMultipleChoice(item, labelx1, labelx2));
            }
            return result;
        }             

  	@Override
	public List<OnereCoefficiente> selectOnereCoeffListByClasse(String codEnte, String codClasse) {
		return oneriDAO.selectOnereCoeffListByClasse(codClasse);
	}       
         
        @Override
        public List<OnereIncremento> selectOnereIncrListByCl(String codEnte, String classe) {
            return oneriDAO.selectOnereIncrListByCl(classe);
        }       
         
//	@Override
//	public List<OnereDestinazioneUso> selectDestinazioneUsoList(String codEnte) {
//		return oneriDAO.selectDestinazioneUsoList();
//	}
//	
//	@Override
//	public List<OnereClasseMaggiorazione> selectOnereClasseMaggList(String codEnte) {
//		return oneriDAO.selectOnereClasseMaggList();
//	}
//	@Override
//	public List<OnereCoefficiente> selectOnereCoeffList(String codEnte) {
//		return oneriDAO.selectOnereCoeffList();
//	}

//	@Override
//	public List<OnereIncremento> selectOnereIncrList(String codEnte) {
//		return oneriDAO.selectOnereIncrList();
//	}
//	@Override
//	public List<OnereIncrementoServizio> selectOnereIncrServList(String codEnte) {
//		return oneriDAO.selectOnereIncrServList();
//	}
//	
//	@Override
//	public List<OnereMonetizzazioneParcheggio> selectOnMonParchList(String codEnte) {
//		return oneriDAO.selectOnMonParchList();
//	}
}
