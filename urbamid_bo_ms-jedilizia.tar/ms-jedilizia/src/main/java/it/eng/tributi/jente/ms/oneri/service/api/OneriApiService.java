package it.eng.tributi.jente.ms.oneri.service.api;

import java.util.List;

import it.eng.tributi.jente.ms.oneri.dto.model.InputList;
import it.eng.tributi.jente.ms.oneri.dto.model.MultipleChoice;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereCoefficiente;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereIncremento;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereResponse;
import it.eng.tributi.jente.ms.oneri.dto.model.SingleChoiceList;

public interface OneriApiService {

    OnereResponse calcolaOneriApi(String codiceFiscale, InputList inputList, String codEnte);
    OnereResponse publicCalcolaOneriApi(InputList inputList, String codEnte);
    OnereResponse publicCalcolaOneriApiBO(InputList inputList, String codEnte);
    
    List<MultipleChoice> selectClassiSuperficieList(String codEnte);
    List<MultipleChoice> selectSuperficiResidenziali(String codEnte);
    List<MultipleChoice> selectCaratteristicheParticolari(String codEnte);
    SingleChoiceList selectTipologiaEdificio(String codEnte);
    SingleChoiceList selectDestinazione(String codEnte);
    SingleChoiceList selectZona(String codEnte);
    SingleChoiceList selectZonaPRG(String codEnte);
    SingleChoiceList selectTipoDomanda(String codEnte);
    SingleChoiceList selectTipoPagamento(String codEnte);    
    List<OnereIncremento> selectOnereIncrListByCl(String codEnte, String classe); 
    List<OnereCoefficiente> selectOnereCoeffListByClasse(String codEnte, String codClasse);
   

//	List<OnereDestinazioneUso> selectDestinazioneUsoList(String codEnte);
//	List<OnereClasseMaggiorazione> selectOnereClasseMaggList(String codEnte);//
//	List<OnereCoefficiente> selectOnereCoeffList(String codEnte);//        //
//	List<OnereIncremento> selectOnereIncrList(String codEnte);
//	List<OnereIncrementoServizio> selectOnereIncrServList(String codEnte);
//	List<OnereMonetizzazioneParcheggio> selectOnMonParchList(String codEnte);

}
