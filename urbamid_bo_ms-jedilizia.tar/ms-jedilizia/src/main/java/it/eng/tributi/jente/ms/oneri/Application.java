package it.eng.tributi.jente.ms.oneri;

import javax.naming.NamingException;
import org.apache.commons.dbcp.BasicDataSource;
import org.eclipse.jetty.plus.jndi.Resource;
import org.eclipse.jetty.webapp.WebAppContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.web.embedded.jetty.JettyServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync
@SpringBootApplication
@EnableAspectJAutoProxy
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
@ComponentScan({ "it.eng.tributi.jente.ms.commons.util", "it.eng.tributi.jente.ms.oneri" })
public class Application {

    @Value("${application.enti.lavoro}")
    private String[] entiLavoro; 
    
    @Autowired
    private Environment env;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
    
     @Bean
    public JettyServletWebServerFactory jettyFactory() {  // if datasouce defind in tomcat xml configuration then no need to create this bean
        return new JettyServletWebServerFactory() {
//            @Override
//            protected JettyWebServer getJettyWebServer(
//                    Server jetty) {
//                return super.getJettyWebServer(jetty);
//            }

            @Override                   // create JNDI resource
            protected void postProcessWebAppContext(WebAppContext context) {
                BasicDataSource datasource = new BasicDataSource();
                datasource.setUrl(env.getProperty("application."+entiLavoro[0]+".db.url"));
                datasource.setDriverClassName(env.getProperty("application."+entiLavoro[0]+".db.driver"));
                datasource.setUsername(env.getProperty("application."+entiLavoro[0]+".db.user"));
                datasource.setPassword(env.getProperty("application."+entiLavoro[0]+".db.password"));
                datasource.setInitialSize(Integer.parseInt(env.getProperty("application."+entiLavoro[0]+".db.initialSize", "5")));
                datasource.setMaxActive(Integer.parseInt(env.getProperty("application."+entiLavoro[0]+".db.maxActive", "20")));
                datasource.setMinIdle(Integer.parseInt(env.getProperty("application."+entiLavoro[0]+".db.minIdle", "10")));
                datasource.setMaxWait(Integer.parseInt(env.getProperty("application."+entiLavoro[0]+".db.maxWait", "30000")));
                datasource.setLogAbandoned(Boolean.parseBoolean(env.getProperty("application."+entiLavoro[0]+".db.logAbandoned", "true")));
                datasource.setRemoveAbandoned(Boolean.parseBoolean(env.getProperty("application."+entiLavoro[0]+".db.removeAbandoned", "true")));
                datasource.setRemoveAbandonedTimeout(Integer.parseInt(env.getProperty("application."+entiLavoro[0]+".db.removeAbandonedTimeout", "300")));
                try {
                    Resource resource = new Resource(env.getProperty("application."+entiLavoro[0]+".db.jndi-name"), datasource);
                } catch (NamingException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        };
    }
    
}
