package it.eng.tributi.jente.ms.oneri.service.impl;

import com.infor.jente.jutility.bean.InforSessionMaster;
import it.arezzo.infor.jente.jedilizia.util.EdiliziaConstants;
import it.arezzo.infor.jente.jutility.UtilString;
import it.eng.tributi.jente.ms.commons.util.auth.dto.JwtUser;
import it.eng.tributi.jente.ms.commons.util.exception.GenericException;
import java.io.FileInputStream;
import java.io.IOException;
import static java.lang.String.format;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

/**
 *
 * @author fbennati
 */
@Service
public abstract class AbstractServiceImpl {

    @Autowired
    protected Environment env;

    @Value("${application.localpath}")
    protected String localPath;
    
    @Value("${application.temppath}")
    protected String tempPath;    
    
    @Value("${application.flussipath}")
    protected String flussiPath;    
    
    @Value("${application.username}")
    protected String username;
    
        
    public static final JwtUser ANONIMOUS = new JwtUser("", "", "ANONIMOUS0123456", null);
    
    public static final  String SLASH=System.getProperty("file.separator");
    
    private static Logger logger = LoggerFactory.getLogger(AbstractServiceImpl.class); 
    
    private String fileProp;  

     protected InforSessionMaster settaSessione(String codEnte) throws Exception
    {
        InforSessionMaster session = new InforSessionMaster();
        session.nuovaSession();
        // Parametri Fissi per Creazione Sessione
        session.setPath("nullo");
        session.setHref("nullo");
        session.setLocalPath(localPath);
        session.setPathTemp(tempPath + SLASH);
        session.setCodiceProcedura(EdiliziaConstants.CODICE_PROCEDURA_EDILZIA);
        
        Properties props = new Properties();
                   
        fileProp = session.getLocalPath() + "conf/jente/" + codEnte + "/jente.properties";        
        FileInputStream file=null;
        
        try
        {
            file=new FileInputStream(fileProp);
            props.load(file);
        }
        catch (Exception ex)
        {           
            throw new GenericException("Errore nella lettura file properties");
        }
        finally
        {
            try
            {
                file.close();
            }
            catch (Exception ex)
            {
            }
        }

//        session.setCodiceEnte(UtilString.vbTrim(props.getProperty("codiceEnte")));
//        session.setDbSchema(UtilString.vbTrim(props.getProperty("dbSchema")));
//        session.setJndiName(UtilString.vbTrim(props.getProperty("jndiName")));
//        
//        if(session.getJndiName().equals(""))
//            session.setJndiName("jdbc/jente/"+codEnte+"/jaxws");

        session.setParamFile(codEnte);
        session.setOperatore(username);
        
        return session;
    }
     
       private static class DBUtils {

        public static final Comparator<Iterable<Integer>> VERSION_COMPARATOR
                = new Comparator<Iterable<Integer>>() {

                    public int compare(Iterable<Integer> o1, Iterable<Integer> o2) {
                        Iterator<Integer> a = o1.iterator();
                        Iterator<Integer> b = o2.iterator();
                        while (a.hasNext() && b.hasNext()) {
                            int comparison = a.next().compareTo(b.next());
                            if (comparison != 0) {
                                return comparison;
                            }
                        }
                        if (a.hasNext()) {
                            return 1;
                        }
                        if (b.hasNext()) {
                            return -1;
                        }
                        return 0;
                    }
                };


        public static Connection getConnection(String jdbcDriver, String jdbcUrl, String jdbcUser, String jdbcPassword) throws ClassNotFoundException, SQLException {
            logger.info(format("[DB] ------------------------------------------------------------------"));
            logger.info(format("[DB] %s", jdbcUrl));
            logger.info(format("[DB] connecting..."));

            Class.forName(jdbcDriver);
            Connection conn = DriverManager.getConnection(jdbcUrl, jdbcUser, jdbcPassword);

            logger.info(format("[DB] connected"));

            try {
                DatabaseMetaData md = conn.getMetaData();
                logger.info(format("[DB] %-15s = %s", "DatabaseProduct", md.getDatabaseProductName()));
                logger.info(format("[DB] %-15s = %s", "DatabaseVersion", md.getDatabaseProductVersion()));
                logger.info(format("[DB] %-15s = %s", "DriverName", md.getDriverName()));
                logger.info(format("[DB] %-15s = %s", "DriverVersion", md.getDriverVersion()));
                logger.info(format("[DB] %-15s = %s.%s", "JDBCVersion", md.getJDBCMajorVersion(), md.getJDBCMinorVersion()));
            } catch (Exception e) {
                logger.error(format("[DB] ERROR: %s", e), e);
            }
            logger.info(format("[DB] ------------------------------------------------------------------"));

            return conn;
        }

        public static List<Integer> version(DatabaseMetaData meta) throws SQLException {
            return Arrays.asList(meta.getJDBCMajorVersion(), meta.getJDBCMinorVersion());
        }
    }
     
     public  Connection getConnessione(InforSessionMaster session, String codiceProcedura, String codiceEnte) {
        logger.debug("CARICO PARAMETRI");
        Properties projEnte = null;
        Properties projMail = null;
        try {
            projEnte = new Properties();
            projEnte.load(new FileInputStream(this.fileProp));

            if (UtilString.vbTrim(projEnte.getProperty("codiceEnte")).equals("")) {
                logger.error("Errore File Parametri [codiceEnte]: Manca Codice Ente");
                return null;
            }
            if (UtilString.vbTrim(projEnte.getProperty("jndiName")).equals("")) {
                logger.error("Errore File Parametri [jndiName]: Manca l'indicazione del JNDI per il Database");
                return null;
            }
            if (UtilString.vbTrim(projEnte.getProperty("dbSchema")).equals("")) {
                logger.error("Errore File Parametri [dbSchema]: Manca Schema del DataBase");
                return null;
            }

            String ente = UtilString.vbTrim(projEnte.getProperty("codiceEnte"));
            if (ente.length() > 2) {
                logger.error("Errore File Parametri [codiceEnte]: Codice Ente troppo Grande (max 2 crt.)");
                return null;
            }

            String jndiName = UtilString.vbTrim(projEnte.getProperty("jndiName"));
            String dbSchema = (UtilString.vbTrim(projEnte.getProperty("dbSchema")) + ".");
//            String pathTemp = UtilString.vbTrim(projEnte.getProperty("pathTemp"));
//            if (!pathTemp.equals("")) {
//                if (!(pathTemp.endsWith("/") || pathTemp.endsWith("\\"))) {
//                    pathTemp += System.getProperty("file.separator");
//                }
//            }

//            dsjEnte = (DataSource) ctx.lookup(jndiName);
            // Parametri Fissi per Creazione Sessione
            session.setPath("nullo");
            session.setHref("nullo");
            session.setLocalPath(localPath);

//            session.setCodiceProcedura("");
//            session.setOperatore("JENTE");
//            session.setAbilUtility("S");
//            session.setRiservatezza("9");

            session.setDescrizioneEnte(UtilString.vbTrim(projEnte.getProperty("descrizioneEnte")));
            session.setCodiceEnte(UtilString.vbTrim(projEnte.getProperty("codiceEnte")));
            session.setOldDbSchema(UtilString.vbTrim(projEnte.getProperty("oldDbSchema") + "."));
            session.setOldCodiceEnte(UtilString.vbTrim(projEnte.getProperty("oldCodiceEnte")));
            session.setParamFile(codiceEnte);
            session.setDbSchema(dbSchema);
            session.setJndiName(jndiName);
            session.setCodiceProcedura(codiceProcedura);

            String jdbcDriver = projEnte.getProperty("JDBC_DRIVER");
            String jdbcUrl = projEnte.getProperty("JDBC_STRCON");
            String jdbcUser = projEnte.getProperty("JDBC_USER");
            String jdbcPassword = projEnte.getProperty("JDBC_PWD");

            logger.error("jdbcDriver=" + jdbcDriver);
            logger.error("jdbcUrl=" + jdbcUrl);
            logger.error("jdbcUser=" + jdbcUser);
            logger.error("jdbcPassword=" + jdbcPassword);
            logger.error("dbSchema=" + dbSchema);

            Connection conn = DBUtils.getConnection(jdbcDriver, jdbcUrl, jdbcUser, jdbcPassword);
//             Connection conn = ParserSql.prendiConnessioneFromDataSource("CO", estrazionePraticheArezzo.getDataSource());            

            logger.debug("CARICATI PARAMETRI");
            return conn;
        } catch (IOException ioe) {
            logger.debug("Errore i-o File Parametri: Manca il File: " + ioe.getMessage(), ioe);
            return null;
//        } catch (NamingException nex) {
//            logger.debug("Errore DataSource: Manca JNDI " + nex.getMessage(), nex);
//            return false;
        } catch (Exception e) {
            logger.debug("Errore Generico File Parametri: Manca il File: " + e.getMessage(), e);
            return null;
        }
    }
    
    
    public String leggiProprieta (String codiceEnte, String labelProprieta) throws GenericException{
        Properties props =leggiFileProperties(codiceEnte);
        String retval=null;
        if(props!=null && props.containsKey(labelProprieta)){
            retval=UtilString.vbTrim(props.getProperty(labelProprieta));
        }     
        else{
            logger.error("File di properties non configurato correttamente, proprietÃ  "+labelProprieta+" non trovata");
            new GenericException("ProprietÃ  "+labelProprieta+" non trovata");
        }
        return retval;
    }      
    
   
     public Properties leggiFileProperties(String codiceEnte) {
        Properties props = new Properties();

        String pathFile = localPath + "conf/ms-jedilizia/" + codiceEnte + "/ms-jedilizia.properties";
        FileInputStream file = null;

        try {
            file = new FileInputStream(pathFile);
            props.load(file);
        } catch (Exception ex) {
            logger.error(ex.getMessage());
            throw new GenericException("Errore nella lettura file properties");
        } finally {
            try {
                file.close();
            } catch (Exception ex) {
            }
        }
        return props;
    }
    


}
