package it.eng.tributi.jente.ms.oneri.util;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SSOUser implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected String nome;
	protected String matricola;
    protected String cognome;
    protected String codFiscale; 
    protected String codUnitaOrganizzativa;
    protected String descrUnitaOrganizzativa;
    protected String codUnitaLivello;
    protected String descrUnitaLivello;
}
