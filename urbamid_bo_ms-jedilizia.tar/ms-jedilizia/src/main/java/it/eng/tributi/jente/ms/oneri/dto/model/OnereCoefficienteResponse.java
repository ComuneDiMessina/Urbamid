package it.eng.tributi.jente.ms.oneri.dto.model;

import it.arezzo.infor.jente.jadmin.service.util.Util;
import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class OnereCoefficienteResponse implements Serializable {

	/**
	 * 
	 */

	private static final long serialVersionUID = 1L;

	protected String codCoefficiente;
	protected String descrizione;
        
    public static OnereCoefficiente getOnereCoefficiente(OnereCoefficienteResponse onereResponse) {
        return (OnereCoefficiente) Util.converti(onereResponse,OnereCoefficiente.class);
    }
    
    public static OnereCoefficienteResponse getOnereCoefficienteResponse(OnereCoefficiente onereCoefficiente) {
        return (OnereCoefficienteResponse) Util.converti(onereCoefficiente,OnereCoefficienteResponse.class);
    }
    
    public static List<OnereCoefficienteResponse> getOnereCoefficienteResponseList(List<OnereCoefficiente> lista) {
        return (List<OnereCoefficienteResponse>) Util.convertiLista(lista, OnereCoefficienteResponse.class);
    }
    
    public static List<OnereCoefficiente> getOnereCoefficienteList(List<OnereCoefficienteResponse> lista) {
        return (List<OnereCoefficiente>) Util.convertiLista(lista, OnereCoefficiente.class);
    }
    
}
