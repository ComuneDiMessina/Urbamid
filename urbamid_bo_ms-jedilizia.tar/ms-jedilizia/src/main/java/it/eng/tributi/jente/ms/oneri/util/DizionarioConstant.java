package it.eng.tributi.jente.ms.oneri.util;

public class DizionarioConstant {

	

	/** DIZIONARIO **/
        public static final String FILE_PDF="ONERI.pdf";
        public static final String FILE_PDF_RATE="ONERI_RATEIZZATI.pdf";
        public static final String PROP_CODICE_COSTO_COSTRUZIONE="costo_costruzione";       
        public static final String PROP_CODICE_ONERI_URBANIZZAZIONE="oneri_urbanizzazione"; 
        
	public static final String DIZ_CATEGORIA = "00";

	/** ONERI **/
	public static final String ONERI_UN_MIS = "UM";
	public static final String ONERI_FASCIA = "OF01";
	public static final String ONERI_FASCIA_$01 = "01";
	public static final String ONERI_FASCIA_$02 = "02";
	public static final String ONERI_FASCIA_$03 = "03";
	public static final String ONERI_RATA_TIPO = "RO00";
	public static final String ONERI_URBA_INT = "OT01";
	public static final String ONERI_URBA_USO = "OD00";
	public static final String ONERI_RATA_TIPO_$URBPRIM = "1";
	public static final String ONERI_RATA_TIPO_$URBSEC = "2";
	public static final String ONERI_RATA_TIPO_$COSTRUZ = "3";
	public static final String ONERI_RATA_NUMERO = "RON0";
        
	public static final String ONERI_CLASS_INT = "OL01";
        public static final String ONERI_CLASS_CARATTERISTICHE="OL03";
        public static final String ONERI_CLASS_TIPOLOGIA="OL04";
        public static final String ONERI_CLASS_DESTINAZIONE="OL05";    
        public static final String ONERI_COEFFICIENTE_RIDUZIONE="OL06"; 
        public static final String ONERI_CODICE_COEFFICIENTE_RIDUZIONE="01"; 
        
        public static final String ONERI_FATTORI_CALCOLO_PARAM1="OL07"; 
        public static final String ONERI_FATTORI_CALCOLO_PARAM2="OL08";         
        public static final String ONERI_CLASS_TIPO_DOMANDA="OL09"; 
        public static final String ONERI_CLASS_SUPERFICI_RESIDENZIALI="OL10";
        public static final String ONERI_CLASS_CARATT_PARTICOLARI="OL11";
        public static final String ONERI_CLASS_TIPO_PAGAMENTO="OL12";
        
	public static final String ONERI_FASE_COSTR = "OF02";
	public static final String ONERI_FASE_COSTR_$INF = "1";
	public static final String ONERI_FASE_COSTR_$SUP = "2";
	public static final String ONERI_COSTR_COEFF_USO = "OZ00";
	public static final String ONERI_COSTR_COEFF_USO_$RES = "OZ01";
	public static final String ONERI_COSTR_COEFF_USO_$TUR = "OZ02";
	public static final String ONERI_COSTR_COEFF_USO_$COM = "OZ03";
	public static final String ONERI_COSTR_CLASSI = "OI01";
	public static final String ONERI_COSTR_CAR = "OI02";
	public static final String ONERI_COSTR_DEST_USO = "OU01";
	public static final String ONERI_COSTR_DEST_USO_$RES = "01";
	public static final String ONERI_COSTR_DEST_USO_$TUR = "02";
	public static final String ONERI_COSTR_DEST_USO_$COM = "03";
        
        
	
	public static final String ONERI_COEFF_ABBATTIMENTO_ACCESSORIO="0.6";
 	public static final String ONERI_COEFF_ABBATTIMENTO_ACCESSORIO_NON_RESIDENZIALE="0.6";
        
        public static final String TIPO_ONERE_COSTO_COSTRUZIONE="C";
        public static final String TIPO_ONERE_MONETIZZAZIONE_PARCHEGGI="P";
	public static final String TIPO_ONERE_URBANIZZAZIONE="U";
        
       public static final String LABEL_SU="ATT_CCSUTOT";
       public static final String LABEL_SNR="ATT_CCSNRTOT";
       public static final String LABEL_SNR_DIVISO_SU="ATT_CCSNR-SU";
       public static final String LABEL_SNRRAGG="ATT_CCSNRRAG";
       public static final String LABEL_SC="ATT_CCSCTOT";     
       
       public static final String LABEL_SARAGG="ATT_CCSARAG";
       public static final String LABEL_ST="ATT_CCSTTOT";         
        
       public static final String LABEL_INCREMENTO1="ATT_CCINCR1";
       public static final String LABEL_INCREMENTO2="ATT_CCINCR2";  
       public static final String LABEL_INCREMENTO2_CASO="ATT_CCINCSER";  
       public static final String LABEL_INCREMENTO3="ATT_CCINCR3"; 
       public static final String LABEL_INCREMENTO3_CASO="ATT_CCPARCR";        
       public static final String LABEL_INCREMENTOTOT="ATT_CCINCRTOT"; 
       public static final String LABEL_RAPPORTORISPETTOSU_PREFIX= "ATT_CCSUTOT";
       public static final String LABEL_PERC_INCREMENTO_CLASSI_SUP_PREFIX= "ATT_CCINCR1_"; 
       public static final String LABEL_MAGGIORAZIONE= "ATT_CCMAG";
       public static final String LABEL_CLASSE_MAGGIORAZIONE= "ATT_CCCLASSE";
       public static final String LABEL_COSTO_COSTRUZIONE= "ATT_CCIMPA";
       public static final String LABEL_COEFFICIENTE_DECREMENTO= "ATT_PERCCMQ";
       public static final String LABEL_COSTO_COSTRUZIONE_DECREMENTATO= "ATT_CCIMPB";
       public static final String LABEL_COSTO_COSTRUZIONE_MAGGIORATO= "ATT_CCIMPC";   
       public static final String LABEL_COSTO_COSTRUZIONE_EDIFICIO= "ATT_CCIMPD";  
       
       public static final String LABEL_ALIQUOTA_A= "ATT_CCALIA";
       public static final String LABEL_ALIQUOTA_B= "ATT_CCALIB";      
       public static final String LABEL_ALIQUOTA_C= "ATT_CCALIC";   
       public static final String LABEL_ALIQUOTA_TOTALE= "ATT_CCALIQUOTA";   
       public static final String LABEL_CONTRIBUTO_DOVUTO= "ATT_CCIMPORTO";
       public static final String LABEL_ECONOMICO_CC= "ECO_CC-1_IMPORTO";
       
       public static final String LABEL_OU_TARIFFA= "ATT_UOTARIFFA";
       public static final String LABEL_OU_TOTALE_ONERE= "ATT_UOIMPORTO";
       
       public static final String LABEL_NUMERO_ALLOGGI_SU_PREFIX= "ATT_CCALL";
       public static final String LABEL_NUMERO_SU_PER_CLASSE_PREFIX= "ATT_CCSU";   
       public static final String LABEL_SUPERFICI_RESIDENZIALI_PREFIX= "ATT_CCSNR";  
       
       
       public static final String LABEL_CARATTERISTICA_PARTICOLARE_PREFIX= "ATT_PARCR"; 
       
       public static final String LABEL_SUPERFICI_ACCESSORIE_CANTINE= "ATT_CCSNR1";  
       public static final String LABEL_SUPERFICI_ACCESSORIE_AUTORIMESSE_SINGOLE= "ATT_CCSNR2";    
       public static final String LABEL_SUPERFICI_ACCESSORIE_AUTORIMESSE_COLLETTIVE= "ATT_CCSNR3";        
       public static final String LABEL_SUPERFICI_ACCESSORIE_ANDRONI= "ATT_CCSNR4";        
       public static final String LABEL_SUPERFICI_ACCESSORIE_BALCONI= "ATT_CCSNR5";     
       
       public static final String LABEL_SUPERFICIE_NETTA_NON_RESIDENZIALE= "ATT_CCSNTOT";    
       public static final String LABEL_SUPERFICIE_ACCESSORI_NON_RESIDENZIALE= "ATT_CCSATOT";  
       
       public static final String LABEL_CODICE_TIPOLOGIA= "ATT_CCTIPO";
       public static final String LABEL_CODICE_DESTINAZIONE= "ATT_CCDEST";  
       
       public static final String LABEL_ONERI_URB_PARAMETRO1= "ATT_UOPRG";       
       public static final String LABEL_ONERI_URB_PARAMETRO2= "ATT_UOZONA";  
       public static final String LABEL_ONERI_URB_VPP= "ATT_UOVPP";  
        
       public static final String LABEL_TIPO_PAGAMENTO= "ATT_TIPOPAG"; 
       public static final String LABEL_TIPO_DOMANDA= "ATT_TIPODOM";        
       public static final String TIPO_PAGAMENTO_UNICA= "UNICA"; 
       public static final String TIPO_PAGAMENTO_RATE= "RATE"; 
       public static final String TIPO_PAGAMENTO_PREMIALITA= "PREMIALITA";      
       
       public static final String CTRL_OBBLIGATORI="ATT_CCALL1#Classi di superficie fino a 95 - Alloggi;ATT_CCALL2#Classi di superficie tra 95 e 110 - Alloggi;ATT_CCALL3#Classi di superficie tra 110 e 130 - Alloggi;ATT_CCALL4#Classi di superficie tra 130 e 160 - Alloggi;ATT_CCALL5#Classi di superficie sopra 160 - Alloggi;ATT_CCSU1#Classi di superficie fino a 95 - Mq;ATT_CCSU2#Classi di superficie tra 95 e 110 - Mq;ATT_CCSU3#Classi di superficie tra 110 e 130 - Mq;ATT_CCSU4#Classi di superficie tra 130 e 160 - Mq;ATT_CCSU5#Classi di superficie sopra 160 - Mq;ATT_CCSNR1#Superficie accessori residenziale - Cantine;ATT_CCSNR2#Superficie accessori residenziale - Autorimesse singole;ATT_CCSNR3#Superficie accessori residenziale - Autorimesse collettive;ATT_CCSNR4#Superficie accessori residenziale - Androni e porticati;ATT_CCSNR5#Superficie accessori residenziale - Logge e balconi;ATT_CCSNTOT#Superficie netta non residenziale;ATT_CCSATOT#Superficie accessori non residenziale;ATT_CCTIPO#Tipologia;ATT_CCDEST#Destinazione;ATT_UOVPP#Volume v.p.p.;ATT_UOPRG#Zona PRG;ATT_UOZONA#Zona;ATT_PARCR1#Caratteristiche particolari - più di un ascensore per scala;ATT_PARCR2#Caratteristiche particolari - più di un ascensore per scala;ATT_PARCR3#Caratteristiche particolari - più di un ascensore per scala;ATT_PARCR4#Caratteristiche particolari - più di un ascensore per scala;ATT_PARCR5#Caratteristiche particolari - più di un ascensore per scala;ATT_TIPOPAG#Tipo Pagamento;ATT_TIPODOM#Tipo Domanda;";

}



