package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;

import it.eng.tributi.jente.ms.oneri.dto.api.SezioneApi;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Sezione  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idSezione;
	protected String nome;
	protected String direzione;
	protected String indirizzo;
	protected String numTel;
	protected String email;
	protected String iban;
	protected String conto;
	
	public static SezioneApi linkSezioneApiFromModel(Sezione sezione){
		SezioneApi link = SezioneApi.builder()
				.nome(sezione.getNome())
				.direzione(sezione.getDirezione())
				.build();
		return link;
	}
}
