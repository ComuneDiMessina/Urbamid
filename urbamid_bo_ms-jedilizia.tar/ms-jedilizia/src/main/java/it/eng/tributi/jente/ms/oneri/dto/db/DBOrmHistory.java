package it.eng.tributi.jente.ms.oneri.dto.db;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=true)
@SuperBuilder
public class DBOrmHistory extends DBOrmBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long rowIdUtenteMod;
	protected Date rowTsMod;
	protected Long idAudit;

}
