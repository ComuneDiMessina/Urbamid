package it.eng.tributi.jente.ms.oneri.dao.mappers;

import it.eng.tributi.jente.ms.oneri.dto.db.OnereCostruzioneDB;
import it.eng.tributi.jente.ms.oneri.dto.db.OnereParcheggioDB;
import it.eng.tributi.jente.ms.oneri.dto.db.OnereRataDB;
import it.eng.tributi.jente.ms.oneri.dto.db.OnereUrbanizzazioneDB;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereClasseMaggiorazione;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereCoefficiente;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereCostruzione;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereDestinazioneCC;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereDestinazioneUso;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereFattoreCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereIncremento;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereIncrementoServizio;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereMonetizzazioneParcheggio;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereParcheggio;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereRata;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereUrbanizzazione;
import it.eng.tributi.jente.ms.oneri.dto.model.ProcedimentoOnereParchSul;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;




@Mapper
public interface OneriMapper {

	List<OnereDestinazioneUso> selectDestinazioneUsoList();
        List<OnereDestinazioneCC> selectDestinazioneCCList();
	List<OnereClasseMaggiorazione> selectOnereClasseMaggList();
	List<OnereCoefficiente> selectOnereCoeffList();
        List<OnereCoefficiente> selectOnereCoeffListByClasse(@Param("classeCoefficiente") String classeCoefficiente);
	List<OnereIncremento> selectOnereIncrList();
        List<OnereIncremento> selectOnereIncrListByCl(@Param("classeIncremento") String classeIncremento);
	List<OnereIncrementoServizio> selectOnereIncrServList();
	List<OnereMonetizzazioneParcheggio> selectOnMonParchList();
	
	
	OnereDestinazioneUso selectDestinazioneUso(@Param("idOneriDestinazioneUso") Long idOneriDestinazioneUso);
	OnereDestinazioneCC selectDestinazioneCC(@Param("idOneriDestinazioneCC") Long idOneriDestinazioneCC);	
        OnereFattoreCalcolo selectFattoreCalcByDestUso(@Param("idOneriDestinazioneUso") Long idOneriDestinazioneUso,@Param("parametro1") String parametro1,@Param("parametro2") String parametro2);
	OnereMonetizzazioneParcheggio selectOnMonParchBySul(@Param("sul") BigDecimal sul);
	OnereCoefficiente selectOnereCoeffById(@Param("idOneriCoefficienti") Long idOneriCoefficienti);
	OnereCoefficiente selectOnereCoeffByCod(@Param("codCoefficiente") String codCoefficiente, @Param("classeCoefficiente") String classeCoefficiente);
	OnereIncremento selectOnereIncrByCod(@Param("codIncremento") String codIncremento, @Param("classeIncremento") String classeIncremento);
	OnereIncrementoServizio selectOnereIncrServByInt(@Param("incremento") BigDecimal incremento);
	OnereClasseMaggiorazione selectOnereClasseMaggByInt(@Param("incremento") BigDecimal incremento);
	
	List<OnereCostruzione> selectOneriCostruzioneByIdProc(@Param("idProcedimento") Long idProcedimento);
	List<OnereUrbanizzazione> selectOneriUrbanizzazioneByIdProc(@Param("idProcedimento") Long idProcedimento);
	List<OnereParcheggio> selectOneriParcheggioByIdProc(@Param("idProcedimento") Long idProcedimento);
	List<OnereRata> selectOneriRateByIdProc(@Param("idProcedimento") Long idProcedimento);

	List<ProcedimentoOnereParchSul> selectProcOnereParchSulByIdProc(@Param("idProcedimento") Long idProcedimento);

	int insertOnereUrbanizzazione(OnereUrbanizzazioneDB onereU);
	int insertHOnereUrbanizzazione(@Param("idOneriUrbaniz") Long idOneriUrbaniz, @Param("idAudit") Long idAudit, @Param("rowStatus") String rowStatus, @Param("rowIdUtenteMod") Long rowIdUtenteMod);
	int updateOnereUrbanizzazione(@Param("onereU")OnereUrbanizzazioneDB onereU, @Param("newRowTsMod") Date newRowTsMod, @Param("idUtenteMod") Long idUtenteMod);
	int deleteOnereUrbanizzazione(@Param("idOneriUrbaniz") Long idOneriUrbaniz);
	int insertProcOnereUrb(@Param("onereU")OnereUrbanizzazioneDB onereU,@Param("idProcedimento") Long idProcedimento);
	int insertHProcOnereUrb(@Param("idOneriUrbaniz") Long idOneriUrbaniz,@Param("idProcedimento") Long idProcedimento, @Param("idAudit") Long idAudit, @Param("rowStatus") String rowStatus, @Param("rowIdUtenteMod") Long rowIdUtenteMod);
	int deleteProcOnereUrb(@Param("idOneriUrbaniz") Long idOneriUrbaniz);
	
	int insertOnereCostruzione(OnereCostruzioneDB onereC);
	int insertHOnereCostruzione(@Param("idOneriCostruzione") Long idOneriCostruzione, @Param("idAudit") Long idAudit, @Param("rowStatus") String rowStatus, @Param("rowIdUtenteMod") Long rowIdUtenteMod);
	int updateOnereCostruzione(@Param("onereC")OnereCostruzioneDB onereC, @Param("newRowTsMod") Date newRowTsMod, @Param("idUtenteMod") Long idUtenteMod);
	int deleteOnereCostruzione(@Param("idOneriCostruzione") Long idOneriCostruzione);
	int insertProcOnereCos(@Param("onereC")OnereCostruzioneDB onereC,@Param("idProcedimento") Long idProcedimento);
	int insertHProcOnereCos(@Param("idOneriCostruzione") Long idOneriCostruzione,@Param("idProcedimento") Long idProcedimento, @Param("idAudit") Long idAudit, @Param("rowStatus") String rowStatus, @Param("rowIdUtenteMod") Long rowIdUtenteMod);
	int deleteProcOnereCos(@Param("idOneriCostruzione") Long idOneriCostruzione);
	
	int insertOnereParcheggio(OnereParcheggioDB onereP);
	int insertHOnereParcheggio(@Param("idOneriParch") Long idOneriParch, @Param("idAudit") Long idAudit, @Param("rowStatus") String rowStatus, @Param("rowIdUtenteMod") Long rowIdUtenteMod);
	int updateOnereParcheggio(@Param("onereP")OnereParcheggioDB onereP, @Param("newRowTsMod") Date newRowTsMod, @Param("idUtenteMod") Long idUtenteMod);
	int deleteOnereParcheggio(@Param("idOneriParch") Long idOneriParch);
	int insertProcOnerePar(@Param("onereP")OnereParcheggioDB onereP,@Param("idProcedimento") Long idProcedimento);
	int insertHProcOnerePar(@Param("idOneriParch") Long idOneriParch,@Param("idProcedimento") Long idProcedimento, @Param("idAudit") Long idAudit, @Param("rowStatus") String rowStatus, @Param("rowIdUtenteMod") Long rowIdUtenteMod);
	int deleteProcOnerePar(@Param("idOneriParch") Long idOneriParch);
	
	int insertOnereRata(OnereRataDB rata);
	int insertHOnereRata(@Param("idOneriRata") Long idOneriRata, @Param("idAudit") Long idAudit, @Param("rowStatus") String rowStatus, @Param("rowIdUtenteMod") Long rowIdUtenteMod);
	int updateOnereRata(@Param("rata")OnereRataDB rata, @Param("newRowTsMod") Date newRowTsMod, @Param("idUtenteMod") Long idUtenteMod);
	int deleteOnereRata(@Param("idOneriRata") Long idOneriRata);
	int insertProcOnereRata(@Param("rata")OnereRataDB onereP,@Param("idProcedimento") Long idProcedimento);
	int insertHProcOnereRata(@Param("idOneriRata") Long idOneriRata,@Param("idProcedimento") Long idProcedimento, @Param("idAudit") Long idAudit, @Param("rowStatus") String rowStatus, @Param("rowIdUtenteMod") Long rowIdUtenteMod);
	int deleteProcOnereRata(@Param("idOneriRata") Long idOneriRata,@Param("idProcedimento") Long idProcedimento);
	
}
