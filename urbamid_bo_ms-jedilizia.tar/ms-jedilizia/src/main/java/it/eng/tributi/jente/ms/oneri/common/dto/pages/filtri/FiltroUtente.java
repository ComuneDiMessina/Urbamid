package it.eng.tributi.jente.ms.oneri.common.dto.pages.filtri;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=true)
@Builder
public class FiltroUtente extends FiltroCommon implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected String matricola;
	protected String cognome;
	protected String nome;
	protected Long idRuolo; 
	protected String email; 
	protected Long idSezione; 
	
	public String getCognomeLike() {
		if(null == cognome || cognome.trim().equals(""))
			 return null;
		else 
			 return "%"+cognome.trim().toUpperCase()+"%";
	}
	
	public String getNomeLike() {
		if(null == nome || nome.trim().equals(""))
			return null;
		else 
			return "%"+nome.trim().toUpperCase()+"%";
	}
	
	@Override
	public void organize() {
		// TODO Auto-generated method stub
		
	}
	
	
	
}