package it.eng.tributi.jente.ms.oneri.common.dto.pages.filtri;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;


@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public abstract class FiltroCommon implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected boolean ricercaEseguita;
	protected String orderBy;
	
	public abstract void organize();
	
	}
