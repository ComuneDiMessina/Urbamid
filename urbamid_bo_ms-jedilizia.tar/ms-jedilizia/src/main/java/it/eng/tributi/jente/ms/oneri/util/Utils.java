package it.eng.tributi.jente.ms.oneri.util;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.lang3.time.FastDateFormat;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.AcroFields;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfStamper;
import com.lowagie.text.pdf.PdfWriter;
import static it.arezzo.infor.jente.jadmin.service.util.Util.setParametersBeanNotNull;
import it.arezzo.infor.jente.jworkflow.commons.util.UWFUtilPdf;
//import it.arezzo.infor.jente.jworkflow.commons.util.UWFUtilPdf;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Set;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Utils {

    public static final String SLASH = System.getProperty("file.separator");
    private static final Date MAX_DATE;

    public static final FastDateFormat DATE_FORMAT_ddMMyyyHHmmss = FastDateFormat.getInstance("dd/MM/yyyy HH:mm:ss");
    public static final FastDateFormat DATE_FORMAT_ddMMyyy = FastDateFormat.getInstance("dd/MM/yyyy");
    public static final FastDateFormat DATE_FORMAT_yyyyMMdd = FastDateFormat.getInstance("yyyy-MM-dd");
    public static final FastDateFormat DATE_FORMAT_HHmmss = FastDateFormat.getInstance("HH:mm:ss");
    public static final FastDateFormat DATE_FORMAT_ALFRESCO = FastDateFormat.getInstance("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
    public static final FastDateFormat DATE_FORMAT_dd_MM_yyyy_HH_mm_ss = FastDateFormat.getInstance("dd_MM_yyyy_hh_mm_ss");
    public static final FastDateFormat DATE_FORMAT_HHmm = FastDateFormat.getInstance("HH:mm");
    public static final String PATTERN_DateTime = "yyyyMMddHHmmss";

    private static Logger logger = LoggerFactory.getLogger(Utils.class);

    static {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(0);
        cal.set(2999, 11, 31, 0, 0, 0);
        MAX_DATE = cal.getTime();
    }

    public static String builIndirizzo(String via, String civico, Integer cap, String comune) {
        StringBuilder sb = new StringBuilder();
        if (null != via) {
            sb.append(via);
        }
        if (null != civico) {
            if (sb.length() > 0) {
                sb.append(" ");
            }
            sb.append(civico);
        }
        if (sb.length() > 0) {
            sb.append(", ");
        }
        if (null != cap) {
            sb.append(cap);
        }
        if (null != comune) {
            if (null != cap) {
                sb.append(" ");
            }
            sb.append(comune);
        }
        return sb.toString();
    }

    public static Date maxDate() {
        return MAX_DATE;
    }

    static public Long flagWrapper(Long value) {
        if (null == value) {
            return -1L;
        }
        return value;
    }

    public static boolean isDateActive(Date dataFinale) {
        return null == dataFinale || !dataFinale.before(MAX_DATE);
    }

    public static Date minDate(Date data1, Date data2) {
        if (null != data1 && null != data2) {
            if (DateUtils.isSameDay(data1, data2)) {
                return data1;
            }
            if (data1.before(data2)) {
                return data1;
            }
            return data2;
        } else {
            return null;
        }

    }

    public static Long getDayBetween(Date data1, Date data2) {
        if (null != data1 && null != data2) {
            LocalDate ld1 = data1.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            LocalDate ld2 = data2.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            return ChronoUnit.DAYS.between(ld1, ld2);
        }
        return null;
    }

    public static Long getMinuteBetween(Date data1, Date data2) {
        if (null != data1 && null != data2) {
            LocalDateTime ld1 = data1.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
            LocalDateTime ld2 = data2.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
            return ChronoUnit.MINUTES.between(ld1, ld2);
        }
        return null;
    }

    public static String buildOrderBy(String column, boolean orderDesc) {
        if (null == column || column.trim().isEmpty()) {
            return null;
        }
        if (column.contains(",")) {
            String[] cs = column.split(",");
            String order = "";
            for (String cc : cs) {
                if (order.length() > 0) {
                    order += ",";
                }
                order += cc.trim() + (orderDesc ? " DESC" : " ASC");
            }
            return order;
        }
        return column.trim() + (orderDesc ? " DESC" : " ASC");
    }

    public static String cleanString(String filename) {
        return filename.replaceAll("[^a-zA-Z0-9.-]", " ");
    }

    /**
     * Merge multiple pdf into one pdf
     *
     * @param list of pdf input stream
     * @param outputStream output file output stream
     * @throws DocumentException
     * @throws IOException
     */
    public static void mergePdf(List<InputStream> list, OutputStream outputStream)
            throws DocumentException, IOException {
        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, outputStream);
        document.open();
        PdfContentByte cb = writer.getDirectContent();

        for (InputStream in : list) {
            PdfReader reader = new PdfReader(in);
            for (int i = 1; i <= reader.getNumberOfPages(); i++) {
                document.newPage();
                //import the page from source pdf
                PdfImportedPage page = writer.getImportedPage(reader, i);
                //add the page to the destination pdf
                cb.addTemplate(page, 0, 0);
            }
        }

        outputStream.flush();
        document.close();
        outputStream.close();
    }

    public static void scriviFile(File dir, String filename, byte[] contenuto) {
        File dest = cancellaFileSeEsiste(dir, filename);
        FileOutputStream stream = null;
        try {
            stream = new FileOutputStream(dest);
            stream.write(contenuto);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            safeClose(stream);
        }
    }

    public static File cancellaFileSeEsiste(File dir, String filename) {
        File res = new File(dir, filename);
        if (res.exists()) {
            res.delete();
        }
        return res;
    }

    public static void safeClose(Closeable closable) {
        if (null == closable) {
            return;
        }
        try {
            closable.close();
        } catch (Exception ex) {

        }
    }

    public static String vbTrim(String stringa) {
        String risultato = "";
        try {
            if (stringa == null) {
                risultato = "";
            } else if (stringa.trim().equals("")) {
                risultato = "";
            } else if (stringa.equals("")) {
                risultato = "";
            } else {
                risultato = stringa.trim();
            }
        } catch (Exception ex) {
            risultato = "";
        }
        return risultato;
    }

    public static String prendiDataOra() {
        Date today = new Date();
        SimpleDateFormat formatter_DateTime = new SimpleDateFormat(PATTERN_DateTime);
        formatter_DateTime.setLenient(true);
        return formatter_DateTime.format(today);
    }

    public  File riempiModelloBase(String codiceFiscale, String codiceEnte, HashMap<String, String> values,String tempPath,String flussiPath, boolean rate) throws Exception {

        String nomeFilePdf=rate?DizionarioConstant.FILE_PDF_RATE:DizionarioConstant.FILE_PDF;
        File result = new File(tempPath + SLASH + codiceFiscale + "_" + prendiDataOra() + "_"+nomeFilePdf);

        File modelloBase = new File(flussiPath+SLASH+codiceEnte+SLASH+nomeFilePdf);
        if (modelloBase.exists()) {
            PdfReader reader = new PdfReader(new FileInputStream(modelloBase));
            PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(result), '\0', true);
            AcroFields form = stamper.getAcroFields();
            Set<String> keys = values.keySet();
            for (String key : keys) {
                UWFUtilPdf.mettiCampoPdf(form, key, values.get(key));
                form.setFieldProperty(key, "textsize", 0, null);
            }

            stamper.close();
            reader.close();
        } else {
            throw new Exception("Modello base non trovato, verificare la proprieta' nel file di properties");
        }

        return result;
    }

    private static String encodeFileToBase64Binary(File file) throws IOException {
        byte[] encoded = Base64.encodeBase64(FileUtils.readFileToByteArray(file));
        return new String(encoded);
    }

    public static it.eng.tributi.jente.ms.oneri.dto.model.Document setDocument(File file) throws IOException {
        it.eng.tributi.jente.ms.oneri.dto.model.Document result = new it.eng.tributi.jente.ms.oneri.dto.model.Document();
        result.setFilename(file.getName());
        result.setMimeType("application/pdf");
        result.setBase64(encodeFileToBase64Binary(file));
        result.setSize(file.length());
        return result;
    }
    
    public static HashMap<String, String> getErrorMap() {
        String[] obbligatori = (DizionarioConstant.CTRL_OBBLIGATORI).split(";");
        HashMap result = null;
        if (obbligatori != null && obbligatori.length > 0) {
            result = new HashMap();
            for (String item : obbligatori) {
                String[] value = item.split("#");
                result.put(value[0], value[1]);
            }
        }
        return result;
    }
    
    public static Object converti(Object input, Class outputElementClass) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        Object target = mapper.convertValue(input, outputElementClass);
        return target;
    }  
    
    public static boolean daRateizzare(String tipoPagamento, boolean daPagareSubito) {
        boolean daRateizzare= true;
        if (tipoPagamento.equals(DizionarioConstant.TIPO_PAGAMENTO_UNICA)
                || !daPagareSubito) {
            daRateizzare= false;
        }
        return daRateizzare;
    }
}
