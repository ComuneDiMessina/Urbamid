package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.util.List;

import it.eng.tributi.jente.ms.oneri.dto.db.RuoloDB;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Ruolo  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idRuolo;
	protected Long idEnte;
	protected String nome;
	protected String descrizione;
	protected Long idApplicativo;
	protected String ruoloActivity;
	protected String codTipoAnag;
	protected List<Funzione> listaFunzioni;
	
	public RuoloDB getDBDTO() {
		return RuoloDB.builder()
				.idRuolo(idRuolo)
				.idEnte(idEnte)
				.nome(nome)
				.descrizione(descrizione)
				.idApplicativo(idApplicativo)
				.ruoloActivity(ruoloActivity)
				.codTipoAnag(codTipoAnag)
				.build();
	}
	
	
}
