package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OneriCostruzioneCalcolo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected CostoCostruzioneAbbattutoCalcolo costoCostruzioneAbbattutoCalcolo;
        protected CoefficienteMaggiorazioneCalcolo coefficienteMaggiorazioneCalcolo;
        
	

}
