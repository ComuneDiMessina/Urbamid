package it.eng.tributi.jente.ms.oneri.dto.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class OnereMonetizzazioneParcheggio implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected Long idMonetizzazione;
	protected BigDecimal mqSogliaMin;
	protected BigDecimal mqSogliaMax;
	protected BigDecimal percCostoBase;
	protected BigDecimal impMonetizzazione;
	protected BigDecimal mqSulMin;
	protected BigDecimal mqSulMax;
	protected Boolean attivo;

}
