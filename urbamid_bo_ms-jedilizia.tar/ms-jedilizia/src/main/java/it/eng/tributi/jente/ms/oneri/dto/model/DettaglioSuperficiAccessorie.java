package it.eng.tributi.jente.ms.oneri.dto.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import it.eng.tributi.jente.ms.oneri.dto.util.BigDecimalItalianDeserializer;
import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DettaglioSuperficiAccessorie implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@JsonDeserialize(using=BigDecimalItalianDeserializer.class)
	protected BigDecimal sulCantine;
	@JsonDeserialize(using=BigDecimalItalianDeserializer.class)
	protected BigDecimal sulAutorimesse;
	@JsonDeserialize(using=BigDecimalItalianDeserializer.class)
	protected BigDecimal sulAndroni;
	@JsonDeserialize(using=BigDecimalItalianDeserializer.class)
	protected BigDecimal sulBalconi;
	@JsonDeserialize(using=BigDecimalItalianDeserializer.class)
	protected BigDecimal sulAutorimesseCollettive;
	
}
