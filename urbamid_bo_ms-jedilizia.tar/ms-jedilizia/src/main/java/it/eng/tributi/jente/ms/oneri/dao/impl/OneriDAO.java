package it.eng.tributi.jente.ms.oneri.dao.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import it.eng.tributi.jente.ms.oneri.dto.db.DBOrmBase;
import it.eng.tributi.jente.ms.oneri.dto.db.OnereCostruzioneDB;
import it.eng.tributi.jente.ms.oneri.dto.db.OnereParcheggioDB;
import it.eng.tributi.jente.ms.oneri.dto.db.OnereRataDB;
import it.eng.tributi.jente.ms.oneri.dto.db.OnereUrbanizzazioneDB;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereClasseMaggiorazione;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereCoefficiente;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereCostruzione;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereDestinazioneUso;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereFattoreCalcolo;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereIncremento;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereIncrementoServizio;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereMonetizzazioneParcheggio;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereParcheggio;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereRata;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereUrbanizzazione;
import it.eng.tributi.jente.ms.oneri.dto.model.ProcedimentoOnereParchSul;
import it.eng.tributi.jente.ms.oneri.util.DBException;
import it.eng.tributi.jente.ms.oneri.dao.mappers.OneriMapper;
import it.eng.tributi.jente.ms.oneri.dto.model.OnereDestinazioneCC;

@Repository
public class OneriDAO {
	
	@Autowired 
	private OneriMapper oneriMapper;
	
	/*CRUD TABELLE*/
	public void insertOnereUrbanizzazione(OnereUrbanizzazioneDB onere,Long idProcedimento) {
		onere.setInsertStatus();
		int numRow = oneriMapper.insertOnereUrbanizzazione(onere);
		if(numRow != 1) {
			throw new DBException("Errore nell'inserimento dell'onere di urbanizzazione");
		}
		int numRowP = oneriMapper.insertProcOnereUrb(onere, idProcedimento);
		if(numRowP != 1) {
			throw new DBException("Errore nell'inserimento della relazione procedimenti/oneri di urbanizzazione");
		}
		int numRowH = oneriMapper.insertHOnereUrbanizzazione(onere.getIdOneriUrbaniz(), onere.getIdAudit(), onere.getRowStatus(), onere.getRowIdUtenteMod());
		if(numRowH != 1) {
			throw new DBException("Errore nell'inserimento dello storico dell'onere di urbanizzazione");
		}
		int numRowHP = oneriMapper.insertHProcOnereUrb(onere.getIdOneriUrbaniz(), idProcedimento, onere.getIdAudit(), onere.getRowStatus(), onere.getRowIdUtenteMod());
		if(numRowHP != 1) {
			throw new DBException("Errore nell'inserimento dello storico della Relazione procedimenti/oneri di urbanizzazion");
		}
	}

	public void insertProcOnereUrbanizzazione(OnereUrbanizzazioneDB onere,Long idProcedimento) {
		onere.setInsertStatus();
		int numRowP = oneriMapper.insertProcOnereUrb(onere, idProcedimento);
		if(numRowP != 1) {
			throw new DBException("Errore nell'inserimento della relazione procedimenti/oneri di urbanizzazione");
		}
		int numRowHP = oneriMapper.insertHProcOnereUrb(onere.getIdOneriUrbaniz(), idProcedimento, onere.getIdAudit(), onere.getRowStatus(), onere.getRowIdUtenteMod());
		if(numRowHP != 1) {
			throw new DBException("Errore nell'inserimento dello storico della Relazione procedimenti/oneri di urbanizzazion");
		}
	}

	public List<OnereDestinazioneUso> selectDestinazioneUsoList() {
		return oneriMapper.selectDestinazioneUsoList();
	}
        
	public List<OnereDestinazioneCC> selectDestinazioneCCList() {
		return oneriMapper.selectDestinazioneCCList();
	}        
	
	public List<OnereClasseMaggiorazione> selectOnereClasseMaggList() {
		return oneriMapper.selectOnereClasseMaggList();
	}
	
	public List<OnereCoefficiente> selectOnereCoeffList() {
		return oneriMapper.selectOnereCoeffList();
	}
        
        public List<OnereCoefficiente> selectOnereCoeffListByClasse(String classeCoefficiente) {
		return oneriMapper.selectOnereCoeffListByClasse(classeCoefficiente);
	}
	
	public List<OnereIncremento> selectOnereIncrList() {
		return oneriMapper.selectOnereIncrList();
	}
	
	public List<OnereIncrementoServizio> selectOnereIncrServList() {
		return oneriMapper.selectOnereIncrServList();
	}
	
	public List<OnereMonetizzazioneParcheggio> selectOnMonParchList() {
		return oneriMapper.selectOnMonParchList();
	}
	
	public void updateOnereUrbanizzazione(OnereUrbanizzazioneDB onere, Date newTsMod, Long idUtenteMod) {
		onere.setUpdateStatus();
		int numRow = oneriMapper.updateOnereUrbanizzazione(onere, newTsMod, idUtenteMod);
		if(numRow != 1) {
			throw new DBException("Errore nell'aggiornamento dell'onere di urbanizzazione");
		}
		int numRowH = oneriMapper.insertHOnereUrbanizzazione(onere.getIdOneriUrbaniz(), onere.getIdAudit(), onere.getRowStatus(), onere.getRowIdUtenteMod());
		if(numRowH != 1) {
			throw new DBException("Errore nell'inserimento dello storico dell'onere di urbanizzazione");
		}
	}

	public void deleteOnereUrbanizzazione(Long idOneriUrbaniz,Long idProcedimento, Long idAudit, Long rowIdUtenteMod, Date tsMod) {
		int numRowHP = oneriMapper.insertHProcOnereUrb(idOneriUrbaniz, idProcedimento, idAudit, DBOrmBase.STATUS_DEL, rowIdUtenteMod);
		if(numRowHP != 1) {
			throw new DBException("Errore nell'inserimento dello storico della Relazione procedimenti/oneri di urbanizzazione");
		}
		int numRowH = oneriMapper.insertHOnereUrbanizzazione(idOneriUrbaniz,idAudit, DBOrmBase.STATUS_DEL, rowIdUtenteMod);
		if(numRowH != 1) {
			throw new DBException("Errore nell'inserimento dello storico dell'onere di urbanizzazione");
		}
		int numRowP = oneriMapper.deleteProcOnereUrb(idOneriUrbaniz);
		if(numRowP != 1) {
			throw new DBException("Errore nella cancellazione della Relazione procedimenti/oneri di urbanizzazione");
		}
		int numRow = oneriMapper.deleteOnereUrbanizzazione(idOneriUrbaniz);
		if(numRow != 1) {
			throw new DBException("Errore nella cancellazione dell'onere di urbanizzazione");
		}
	}

	public void insertOnereCostruzione(OnereCostruzioneDB onere,Long idProcedimento) {
		onere.setInsertStatus();
		int numRow = oneriMapper.insertOnereCostruzione(onere);
		if(numRow != 1) {
			throw new DBException("Errore nell'inserimento dell'onere di costruzione");
		}
		int numRowP = oneriMapper.insertProcOnereCos(onere, idProcedimento);
		if(numRowP != 1) {
			throw new DBException("Errore nell'inserimento della relazione procedimenti/oneri di costruzione");
		}
		int numRowH = oneriMapper.insertHOnereCostruzione(onere.getIdOneriCostruzione(), onere.getIdAudit(), onere.getRowStatus(), onere.getRowIdUtenteMod());
		if(numRowH != 1) {
			throw new DBException("Errore nell'inserimento dello storico dell'onere di costruzione");
		}
		int numRowHP = oneriMapper.insertHProcOnereCos(onere.getIdOneriCostruzione(), idProcedimento, onere.getIdAudit(), onere.getRowStatus(), onere.getRowIdUtenteMod());
		if(numRowHP != 1) {
			throw new DBException("Errore nell'inserimento dello storico della Relazione procedimenti/oneri di costruzione");
		}
	}

	public void insertProcOnereCostruzione(OnereCostruzioneDB onere,Long idProcedimento) {
		onere.setInsertStatus();
		int numRowP = oneriMapper.insertProcOnereCos(onere, idProcedimento);
		if(numRowP != 1) {
			throw new DBException("Errore nell'inserimento della relazione procedimenti/oneri di costruzione");
		}
		int numRowHP = oneriMapper.insertHProcOnereCos(onere.getIdOneriCostruzione(), idProcedimento, onere.getIdAudit(), onere.getRowStatus(), onere.getRowIdUtenteMod());
		if(numRowHP != 1) {
			throw new DBException("Errore nell'inserimento dello storico della Relazione procedimenti/oneri di costruzione");
		}
	}

	public void updateOnereCostruzione(OnereCostruzioneDB onere, Date newTsMod, Long idUtenteMod) {
		onere.setUpdateStatus();
		int numRow = oneriMapper.updateOnereCostruzione(onere, newTsMod, idUtenteMod);
		if(numRow != 1) {
			throw new DBException("Errore nell'aggiornamento dell'onere di costruzione");
		}
		int numRowH = oneriMapper.insertHOnereCostruzione(onere.getIdOneriCostruzione(), onere.getIdAudit(), onere.getRowStatus(), onere.getRowIdUtenteMod());
		if(numRowH != 1) {
			throw new DBException("Errore nell'inserimento dello storico dell'onere di costruzione");
		}
	}

	public void deleteOnereCostruzione(Long idOneriCostruzione,Long idProcedimento, Long idAudit, Long rowIdUtenteMod, Date tsMod) {
		int numRowHP = oneriMapper.insertHProcOnereCos(idOneriCostruzione, idProcedimento, idAudit, DBOrmBase.STATUS_DEL, rowIdUtenteMod);
		if(numRowHP != 1) {
			throw new DBException("Errore nell'inserimento dello storico della Relazione procedimenti/oneri di costruzione");
		}
		int numRowH = oneriMapper.insertHOnereCostruzione(idOneriCostruzione,idAudit, DBOrmBase.STATUS_DEL, rowIdUtenteMod);
		if(numRowH != 1) {
			throw new DBException("Errore nell'inserimento dello storico dell'onere di costruzione");
		}
		int numRowP = oneriMapper.deleteProcOnereCos(idOneriCostruzione);
		if(numRowP != 1) {
			throw new DBException("Errore nella cancellazione della Relazione procedimenti/oneri di costruzione");
		}
		int numRow = oneriMapper.deleteOnereCostruzione(idOneriCostruzione);
		if(numRow != 1) {
			throw new DBException("Errore nella cancellazione dell'onere di costruzione");
		}
	}

	public void insertOnereParcheggio(OnereParcheggioDB onere,Long idProcedimento) {
		onere.setInsertStatus();
		int numRow = oneriMapper.insertOnereParcheggio(onere);
		if(numRow != 1) {
			throw new DBException("Errore nell'inserimento dell'onere di parcheggio");
		}
		int numRowP = oneriMapper.insertProcOnerePar(onere, idProcedimento);
		if(numRowP != 1) {
			throw new DBException("Errore nell'inserimento della relazione procedimenti/oneri di parcheggio");
		}
		int numRowH = oneriMapper.insertHOnereParcheggio(onere.getIdOneriParch(), onere.getIdAudit(), onere.getRowStatus(), onere.getRowIdUtenteMod());
		if(numRowH != 1) {
			throw new DBException("Errore nell'inserimento dello storico dell'onere di parcheggio");
		}
		int numRowHP = oneriMapper.insertHProcOnerePar(onere.getIdOneriParch(), idProcedimento, onere.getIdAudit(), onere.getRowStatus(), onere.getRowIdUtenteMod());
		if(numRowHP != 1) {
			throw new DBException("Errore nell'inserimento dello storico della Relazione procedimenti/oneri di parcheggio");
		}
	}

	public void insertProcOnereParcheggio(OnereParcheggioDB onere,Long idProcedimento) {
		onere.setInsertStatus();
		int numRowP = oneriMapper.insertProcOnerePar(onere, idProcedimento);
		if(numRowP != 1) {
			throw new DBException("Errore nell'inserimento della relazione procedimenti/oneri di parcheggio");
		}
		int numRowHP = oneriMapper.insertHProcOnerePar(onere.getIdOneriParch(), idProcedimento, onere.getIdAudit(), onere.getRowStatus(), onere.getRowIdUtenteMod());
		if(numRowHP != 1) {
			throw new DBException("Errore nell'inserimento dello storico della Relazione procedimenti/oneri di parcheggio");
		}
	}

	public void updateOnereParcheggio(OnereParcheggioDB onere, Date newTsMod, Long idUtenteMod) {
		onere.setUpdateStatus();
		int numRow = oneriMapper.updateOnereParcheggio(onere, newTsMod, idUtenteMod);
		if(numRow != 1) {
			throw new DBException("Errore nell'aggiornamento dell'onere di parcheggio");
		}
		int numRowH = oneriMapper.insertHOnereParcheggio(onere.getIdOneriParch(), onere.getIdAudit(), onere.getRowStatus(), onere.getRowIdUtenteMod());
		if(numRowH != 1) {
			throw new DBException("Errore nell'inserimento dello storico dell'onere di parcheggio");
		}
	}

	public void deleteOnereParcheggio(Long idOneriParch,Long idProcedimento, Long idAudit, Long rowIdUtenteMod, Date tsMod) {
		int numRowHP = oneriMapper.insertHProcOnerePar(idOneriParch, idProcedimento, idAudit, DBOrmBase.STATUS_DEL, rowIdUtenteMod);
		if(numRowHP != 1) {
			throw new DBException("Errore nell'inserimento dello storico della Relazione procedimenti/oneri di parcheggio");
		}
		int numRowH = oneriMapper.insertHOnereParcheggio(idOneriParch,idAudit, DBOrmBase.STATUS_DEL, rowIdUtenteMod);
		if(numRowH != 1) {
			throw new DBException("Errore nell'inserimento dello storico dell'onere di parcheggio");
		}
		int numRowP = oneriMapper.deleteProcOnerePar(idOneriParch);
		if(numRowP != 1) {
			throw new DBException("Errore nella cancellazione Relazione procedimenti/oneri di parcheggio");
		}
		int numRow = oneriMapper.deleteOnereParcheggio(idOneriParch);
		if(numRow != 1) {
			throw new DBException("Errore nella cancellazione dell'onere di parcheggio");
		}
	}

	public void insertRataOnere(OnereRataDB rata,Long idProcedimento) {
		rata.setInsertStatus();
		int numRow = oneriMapper.insertOnereRata(rata);
		if(numRow != 1) {
			throw new DBException("Errore nell'inserimento della rata dell'onere");
		}
		int numRowP = oneriMapper.insertProcOnereRata(rata, idProcedimento);
		if(numRowP != 1) {
			throw new DBException("Errore nell'inserimento della relazione procedimenti/rata dell'onere");
		}
		int numRowH = oneriMapper.insertHOnereRata(rata.getIdOneriRata(), rata.getIdAudit(), rata.getRowStatus(), rata.getRowIdUtenteMod());
		if(numRowH != 1) {
			throw new DBException("Errore nell'inserimento dello storico della rata dell'onere");
		}
		int numRowHP = oneriMapper.insertHProcOnereRata(rata.getIdOneriRata(), idProcedimento, rata.getIdAudit(), rata.getRowStatus(), rata.getRowIdUtenteMod());
		if(numRowHP != 1) {
			throw new DBException("Errore nell'inserimento dello storico della Relazione procedimenti/rata dell'onere");
		}
	}

	public void updateRataOnere(OnereRataDB rata, Date newTsMod, Long idUtenteMod) {
		rata.setUpdateStatus();
		int numRow = oneriMapper.updateOnereRata(rata, newTsMod, idUtenteMod);
		if(numRow != 1) {
			throw new DBException("Errore nell'aggiornamento della rata dell'onere");
		}
		int numRowH = oneriMapper.insertHOnereRata(rata.getIdOneriRata(), rata.getIdAudit(), rata.getRowStatus(), rata.getRowIdUtenteMod());
		if(numRowH != 1) {
			throw new DBException("Errore nell'inserimento dello storico della rata dell'onere");
		}
	}

	public void deleteRataOnere(Long idOneriRata,Long idProcedimento, Long idAudit, Long rowIdUtenteMod, Date tsMod) {
		int numRowHP = oneriMapper.insertHProcOnereRata(idOneriRata, idProcedimento, idAudit, DBOrmBase.STATUS_DEL, rowIdUtenteMod);
		if(numRowHP != 1) {
			throw new DBException("Errore nell'inserimento dello storico della Relazione procedimenti/rata dell'onere");
		}
		int numRowH = oneriMapper.insertHOnereRata(idOneriRata,idAudit, DBOrmBase.STATUS_DEL, rowIdUtenteMod);
		if(numRowH != 1) {
			throw new DBException("Errore nell'inserimento dello storico della rata dell'onere");
		}
		int numRowP = oneriMapper.deleteProcOnereRata(idOneriRata,idProcedimento);
		if(numRowP != 1) {
			throw new DBException("Errore nella cancellazione Relazione procedimenti/rata dell'onere");
		}
		int numRow = oneriMapper.deleteOnereRata(idOneriRata);
		if(numRow != 1) {
			throw new DBException("Errore nella cancellazione della rata dell'onere");
		}
	}

	/*FINE****CRUD TABELLE*/
	
	public OnereDestinazioneUso selectDestinazioneUso(Long idOneriDestinazioneUso) {
		return oneriMapper.selectDestinazioneUso(idOneriDestinazioneUso);
	}
        
	public OnereDestinazioneCC selectDestinazioneCC(Long idOneriDestinazioneCC) {
		return oneriMapper.selectDestinazioneCC(idOneriDestinazioneCC);
	}
        
	public OnereFattoreCalcolo selectFattoreCalcByDestUso(Long idOneriDestinazioneUso,String parametro1,String parametro2) {
		return oneriMapper.selectFattoreCalcByDestUso(idOneriDestinazioneUso, parametro1, parametro2);
	}
	public OnereMonetizzazioneParcheggio selectOnMonParchBySul(BigDecimal sul) {
		return oneriMapper.selectOnMonParchBySul(sul);
	}
	public OnereCoefficiente selectOnereCoeffById(Long idOneriCoefficienti, String codEnte) {
		return oneriMapper.selectOnereCoeffById(idOneriCoefficienti);
	}
	public OnereCoefficiente selectOnereCoeffByCod(String codCoefficiente, String classeCoefficiente) {
		return oneriMapper.selectOnereCoeffByCod(codCoefficiente,classeCoefficiente);
	}
	public OnereIncremento selectOnereIncrByCod(String codIncremento, String classeIncremento) {
		return oneriMapper.selectOnereIncrByCod(codIncremento,classeIncremento);
	}
	public List<OnereIncremento> selectOnereIncrListByCl(String classeIncremento) {
		return oneriMapper.selectOnereIncrListByCl(classeIncremento);
	}
	public OnereIncrementoServizio selectOnereIncrServByInt(BigDecimal incremento) {
		return oneriMapper.selectOnereIncrServByInt(incremento);
	}
	public OnereClasseMaggiorazione selectOnereClasseMaggByInt(BigDecimal incremento) {
		return oneriMapper.selectOnereClasseMaggByInt(incremento);
	}

	public List<OnereCostruzione> selectOneriCostruzioneByIdProc(Long idProcedimento) {
		return oneriMapper.selectOneriCostruzioneByIdProc(idProcedimento);
	}
	public List<OnereUrbanizzazione> selectOneriUrbanizzazioneByIdProc(Long idProcedimento) {
		return oneriMapper.selectOneriUrbanizzazioneByIdProc(idProcedimento);
	}
	public List<OnereParcheggio> selectOneriParcheggioByIdProc(Long idProcedimento) {
		return oneriMapper.selectOneriParcheggioByIdProc(idProcedimento);
	}
	public List<OnereRata> selectOneriRateByIdProc(Long idProcedimento) {
		return oneriMapper.selectOneriRateByIdProc(idProcedimento);
	}

	public List<ProcedimentoOnereParchSul> selectProcOnereParchSulByIdProc(Long idProcedimento) {
		return oneriMapper.selectProcOnereParchSulByIdProc(idProcedimento);
	}

}
